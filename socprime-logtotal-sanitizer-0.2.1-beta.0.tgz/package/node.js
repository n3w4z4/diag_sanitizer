import { createSanitizer, toNullSink } from './chunk-5UDGYWP3.js';
export { createSanitizer, fromBlob, fromString, fromWebStream, generateKey, mergeReports, planLineAlignedRanges, sanitizeStream, sanitizeText, toCallbackSink, toNullSink, toStringSink } from './chunk-5UDGYWP3.js';
export { InvalidKeyError, InvalidOptionError, InvalidRuleError, SanitizationAbortedError, SanitizerError, UnknownRuleError, builtinRuleIds, builtinRules, defineRule, getBuiltinRule, isSanitizerError } from './chunk-X2QYRBY6.js';
import { createReadStream, createWriteStream } from 'fs';
import { once } from 'events';
import { finished } from 'stream/promises';

var DEFAULT_CHUNK_BYTES = 4 * 1024 * 1024;
function fromNodeStream(stream) {
  return {
    async *[Symbol.asyncIterator]() {
      const decoder = new TextDecoder("utf-8");
      for await (const chunk of stream) {
        const text = typeof chunk === "string" ? chunk : decoder.decode(chunk, { stream: true });
        if (text.length > 0) {
          yield text;
        }
      }
      const tail = decoder.decode();
      if (tail.length > 0) {
        yield tail;
      }
    }
  };
}
function fromFile(path, chunkBytes = DEFAULT_CHUNK_BYTES) {
  return fromNodeStream(createReadStream(path, { highWaterMark: chunkBytes }));
}
function toNodeStream(stream) {
  return {
    async write(chunk) {
      if (!stream.write(chunk)) {
        await once(stream, "drain");
      }
    }
  };
}
function toFile(path) {
  const stream = createWriteStream(path, { encoding: "utf-8" });
  const target = toNodeStream(stream);
  return {
    write: target.write.bind(target),
    async close() {
      stream.end();
      await finished(stream);
    }
  };
}
async function sanitizeFile(options) {
  const { input, output, chunkBytes, onProgress, signal, ...sanitizerOptions } = options;
  const sanitizer = createSanitizer(sanitizerOptions);
  const sink = output === void 0 ? toNullSink() : toFile(output);
  return sanitizer.sanitizeStream(fromFile(input, chunkBytes), sink, { onProgress, signal });
}

export { fromFile, fromNodeStream, sanitizeFile, toFile, toNodeStream };
//# sourceMappingURL=node.js.map
//# sourceMappingURL=node.js.map