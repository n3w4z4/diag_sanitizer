'use strict';

// src/core/errors.ts
var ERROR_BRAND = /* @__PURE__ */ Symbol.for("@socprime/logtotal-sanitizer/error");
var SanitizerError = class extends Error {
  /** Machine-readable cause, stable across releases. */
  code;
  constructor(code, message) {
    super(message);
    this.name = "SanitizerError";
    this.code = code;
    Object.defineProperty(this, ERROR_BRAND, { value: true, enumerable: false });
  }
};
var InvalidRuleError = class extends SanitizerError {
  constructor(message) {
    super("INVALID_RULE", message);
    this.name = "InvalidRuleError";
  }
};
var UnknownRuleError = class extends SanitizerError {
  constructor(message) {
    super("UNKNOWN_RULE", message);
    this.name = "UnknownRuleError";
  }
};
var InvalidKeyError = class extends SanitizerError {
  constructor(message) {
    super("INVALID_KEY", message);
    this.name = "InvalidKeyError";
  }
};
var InvalidOptionError = class extends SanitizerError {
  constructor(message) {
    super("INVALID_OPTION", message);
    this.name = "InvalidOptionError";
  }
};
var SanitizationAbortedError = class extends SanitizerError {
  constructor(message = "Sanitization was aborted.") {
    super("ABORTED", message);
    this.name = "SanitizationAbortedError";
  }
};
function isSanitizerError(value) {
  return typeof value === "object" && value !== null && ERROR_BRAND in value;
}

// src/rules/definitions/geoLocation.ts
function parseLatLonPair(match) {
  const stripped = match.replace(/[()\s]/g, "");
  if (!/^-?\d+\.\d+[,;]-?\d+\.\d+$/.test(stripped)) {
    return null;
  }
  const [latStr, lonStr] = stripped.split(/[,;]/);
  const lat = Number(latStr);
  const lon = Number(lonStr);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
    return null;
  }
  return { lat, lon };
}
function isPlausibleLatLon(lat, lon) {
  if (lat === 0 && lon === 0) {
    return false;
  }
  return lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180;
}
function validateGeo(match) {
  const pair = parseLatLonPair(match);
  if (pair) {
    return isPlausibleLatLon(pair.lat, pair.lon);
  }
  return true;
}
var LAT_KEY = "(?:latitude|lat)";
var LON_KEY = "(?:longitude|long|lon|lng)";
var ZIP_KEY = "(?:zipCode|postalCode|postcode|zip)";
var ADDR_KEY = "(?:addressLine1|address|street)";
var OLC = "[23456789CFGHJMPQRVWXcfghjmpqrvwx]";
var GEOHASH = "[0-9b-hjkmnp-zB-HJKMNP-Z]";
var geoLocationRule = {
  id: "geoLocation",
  label: "Geo location",
  description: "Coordinates, geohashes, plus codes, postcodes and context-anchored addresses become a stable <GEO:\u2026> token \u2014 the same value maps to the same token everywhere within a session.",
  mode: "pseudo",
  token: "GEO",
  patterns: [
    "(?:\\(\\s*-?\\d{1,3}\\.\\d{3,}\\s*[,;]\\s*-?\\d{1,3}\\.\\d{3,}\\s*\\))",
    "(?:(?<![\\d.])-?\\d{1,3}\\.\\d{3,}\\s*[,;]\\s*-?\\d{1,3}\\.\\d{3,}(?!\\d))",
    `(?:\\b${LAT_KEY}\\s*[=:]\\s*)(-?\\d{1,3}\\.\\d+)`,
    `(?:\\b${LON_KEY}\\s*[=:]\\s*)(-?\\d{1,3}\\.\\d+)`,
    `(?:\\bgeohash\\s*[=:]\\s*)(${GEOHASH}{5,12}\\b)`,
    `(?:(?<![\\w+])${OLC}{4,8}\\+${OLC}{2,3}(?![\\w+]))`,
    `(?:\\b\\d{1,3}\xB0\\d{1,2}'\\d{1,2}(?:\\.\\d+)?"[NSEW]\\b)`,
    "(?:\\b[A-Za-z]{1,2}\\d{1,2}[A-Za-z]?\\s\\d[A-Za-z]{2}\\b)",
    `(?:\\b${ZIP_KEY}\\s*[=:]\\s*)(\\d{5}(?:-\\d{4})?\\b)`
  ],
  aggressivePatterns: [
    "(?:\\(\\s*-?\\d{1,3}\\.\\d{2,}\\s*[,;]\\s*-?\\d{1,3}\\.\\d{2,}\\s*\\))",
    "(?:(?<![\\d.])-?\\d{1,3}\\.\\d{2,}\\s*[,;]\\s*-?\\d{1,3}\\.\\d{2,}(?!\\d))",
    `(?:(?<=\\b${ADDR_KEY}\\s*[=:]\\s*)[^\\n"'<>]{5,80})`
  ],
  validate: validateGeo,
  jsonKeys: [
    "latitude",
    "longitude",
    "lat",
    "lon",
    "lng",
    "long",
    "coordinates",
    "coords",
    "geo",
    "streetAddress",
    "addressLine1",
    "addressLine2",
    "postalCode",
    "postcode",
    "zip",
    "zipCode",
    "geohash",
    "address",
    "homeAddress",
    "billingAddress",
    "shippingAddress",
    "mailingAddress",
    "postalAddress",
    "residentialAddress",
    "street",
    "streetName",
    "houseNumber",
    "addressLine",
    "addressLine3",
    "postCode",
    "plz",
    "gps",
    "gpsCoordinates",
    "geoPoint",
    "geoLocation",
    "latLng",
    "latLon"
  ],
  jsonKeyContains: [
    "streetaddress",
    "homeaddress",
    "billingaddress",
    "shippingaddress",
    "mailingaddress",
    "postaladdress",
    "addressline",
    "latitude",
    "longitude",
    "postalcode",
    "zipcode"
  ]
};

// src/rules/definitions/govIdentifiers.ts
function luhnCheck(digits) {
  if (!/^\d+$/.test(digits) || /^0+$/.test(digits)) {
    return false;
  }
  let sum = 0;
  let doubleIt = false;
  for (let i = digits.length - 1; i >= 0; i -= 1) {
    let digit = Number(digits[i]);
    if (doubleIt) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    sum += digit;
    doubleIt = !doubleIt;
  }
  return sum % 10 === 0;
}
function isValidSsn(area, group, serial) {
  if (area === "000" || area === "666" || area.startsWith("9")) {
    return false;
  }
  return group !== "00" && serial !== "0000";
}
function isValidItin(area, group, serial) {
  if (!area.startsWith("9") || serial === "0000") {
    return false;
  }
  const groupNum = Number(group);
  return groupNum >= 70 && groupNum <= 88 || groupNum >= 90 && groupNum <= 92 || groupNum >= 94 && groupNum <= 99;
}
function isValidNhs(digits) {
  if (!/^\d{10}$/.test(digits) || /^0+$/.test(digits)) {
    return false;
  }
  let sum = 0;
  for (let i = 0; i < 9; i += 1) {
    sum += Number(digits[i]) * (10 - i);
  }
  const remainder = sum % 11;
  let check = 11 - remainder;
  if (check === 11) {
    check = 0;
  }
  if (check === 10) {
    return false;
  }
  return check === Number(digits[9]);
}
function validateGovId(match) {
  const dashed = /^(\d{3})-(\d{2})-(\d{4})$/.exec(match);
  if (dashed?.[1] && dashed[2] && dashed[3]) {
    return isValidSsn(dashed[1], dashed[2], dashed[3]) || isValidItin(dashed[1], dashed[2], dashed[3]);
  }
  if (/^\d{3}-\d{3}-\d{3}$/.test(match)) {
    return luhnCheck(match.replace(/-/g, ""));
  }
  if (/^\d{3} \d{3} \d{4}$/.test(match)) {
    return isValidNhs(match.replace(/ /g, ""));
  }
  const nhsPrefixed = /(?:NHS|nhs)(?:[_-]?number)?\s*[=:]\s*(\d{10})$/.exec(match);
  const nhsDigits = nhsPrefixed?.[1];
  if (nhsDigits) {
    return isValidNhs(nhsDigits);
  }
  return true;
}
var SSN_CTX = "(?:[Ss][Ss][Nn]|[Ee][Ii][Nn]|[Ss][Ii][Nn]|tax[_-]?id|social[_ -]?security(?:[_ -]?number)?)";
var ID_CTX = "(?:passport(?:_no|_number)?|driver[_-]?license|national[_-]?id|tax[_-]?id)";
var govIdentifiersRule = {
  id: "govIds",
  label: "Government identifiers",
  description: "Passport numbers, tax numbers, SSNs and similar IDs are redacted outright.",
  mode: "mask",
  token: "GOV_ID",
  patterns: [
    "(?:(?<![A-Z0-9<])P<[A-Z0-9<]{42}(?![A-Z0-9<]))",
    "(?:\\b\\d{3}-\\d{2}-\\d{4}\\b)",
    "(?:\\b\\d{3}-\\d{3}-\\d{3}\\b)",
    "(?:\\b\\d{3} \\d{3} \\d{4}\\b)",
    "(?:\\b(?:NHS|nhs)(?:[_-]?number)?\\s*[=:]\\s*\\d{10}\\b)",
    "(?:\\b(?!BG|GB|NK|KN|TN|NT|ZZ)[A-CEGHJ-PR-TW-Z][A-CEGHJ-NPR-TW-Z]\\d{6}\\s?[A-D]\\b)",
    "(?:(?<![A-Za-z0-9\u0410-\u042F\u0406\u0407\u0404\u0490\u0430-\u044F\u0456\u0457\u0454\u0491])[\u0410-\u042F\u0406\u0407\u0404\u0490]{2}\\d{6}\\b)",
    `(?:\\b${SSN_CTX}\\s*[=:]?\\s*)(\\d{9})\\b`,
    "(?:(?:\u0406\u041F\u041D|\u0420\u041D\u041E\u041A\u041F\u041F|tax[_-]?id)\\s*[=:]?\\s*)(\\d{10})\\b",
    `(?:\\b${ID_CTX}\\s*[=:]\\s*)([A-Za-z0-9<]{5,32})`
  ],
  aggressivePatterns: ["(?:\\b[A-Z]{1,2}\\d{6,9}\\b)", "(?:\\b\\d{9,11}\\b)"],
  validate: validateGovId,
  jsonKeys: [
    "ssn",
    "passportNumber",
    "taxId",
    "nationalId",
    "socialSecurityNumber",
    "passport",
    "nino",
    "nhsNumber",
    "driverLicense",
    "licenseNumber",
    "personalId",
    "dob",
    "dateOfBirth",
    "passportNo",
    "passportId",
    "idNumber",
    "idCardNumber",
    "identityCardNumber",
    "nationalIdNumber",
    "nationalInsuranceNumber",
    "sin",
    "socialInsuranceNumber",
    "tin",
    "taxNumber",
    "taxIdentificationNumber",
    "ein",
    "itin",
    "ssnLast4",
    "driversLicense",
    "driverLicenseNumber",
    "drivingLicence",
    "dlNumber",
    "personalCode",
    "personalNumber",
    "birthNumber",
    "rodneCislo",
    "pesel",
    "oib",
    "cnp",
    "dni",
    "nie",
    "nif",
    "nir",
    "codiceFiscale",
    "steuerId",
    "bsn",
    "cpf",
    "curp",
    "aadhaar",
    "rnokpp",
    "ipn",
    "inn",
    "snils",
    "birthDate",
    "placeOfBirth",
    "mothersMaidenName",
    "residencePermit",
    "voterId"
  ],
  jsonKeyContains: [
    "passport",
    "taxid",
    "nationalid",
    "socialsecurity",
    "driverlicen",
    "drivinglicen"
  ]
};

// src/rules/definitions/healthInfo.ts
function isValidDea(match) {
  if (!/^[ABFGMPRX][A-Z9]\d{7}$/.test(match)) {
    return false;
  }
  const digits = match.slice(2);
  const sum = Number(digits[0]) + Number(digits[2]) + Number(digits[4]) + 2 * (Number(digits[1]) + Number(digits[3]) + Number(digits[5]));
  return sum % 10 === Number(digits[6]);
}
function validateHealth(match) {
  if (/^[ABFGMPRX][A-Z9]\d{7}$/.test(match)) {
    return isValidDea(match);
  }
  return true;
}
var MRN_KEY = "(?:[Mm][Rr][Nn]|medical[_-]?record(?:[_-]?number)?)";
var healthInfoRule = {
  id: "healthInfo",
  label: "Protected health information",
  description: "PHI in SOC logs is almost always structured: JSON field names (diagnosis, medication, MRN, \u2026) carry most of the coverage. Freeform patterns only match context-anchored medical codes (ICD, SNOMED, LOINC, NDC, DEA, MRN).",
  mode: "mask",
  token: "PHI",
  patterns: [
    "(?:\\b(?:[Ii][Cc][Dd]-10|[Ii][Cc][Dd]10):?\\s*[A-Z]\\d{2}(?:\\.\\d{1,4})?\\b)",
    "(?:\\b(?:[Ii][Cc][Dd]-9|[Ii][Cc][Dd]9):?\\s*(?:[VE]\\d{2,3}|\\d{3})(?:\\.\\d{1,2})?\\b)",
    "(?:\\b(?:SNOMED(?:\\s*CT)?|[Ss]nomed(?:\\s*CT)?)[:\\s]+\\d{6,18}\\b)",
    "(?:\\b(?:LOINC|[Ll]oinc)[:\\s]+\\d{1,5}-\\d\\b)",
    "(?:\\b(?:NDC|[Nn]dc)[:\\s]+\\d{4,5}-\\d{3,4}-\\d{1,2}\\b)",
    "(?:\\b[ABFGMPRX][A-Z9]\\d{7}\\b)",
    "(?:\\b(?:[Nn][Pp][Ii])\\s*[=:]\\s*\\d{10}\\b)",
    `(?:\\b${MRN_KEY}\\s*[=:]\\s*)([A-Za-z0-9-]{4,})\\b`
  ],
  aggressivePatterns: ["(?:(?<![A-Za-z0-9])[A-TV-Z]\\d{2}(?:\\.\\w{1,4})?(?![A-Za-z0-9:]))"],
  validate: validateHealth,
  jsonKeys: [
    "diagnosis",
    "prescription",
    "medication",
    "icd10",
    "icd9",
    "snomed",
    "condition",
    "allergy",
    "allergies",
    "bloodType",
    "patientId",
    "mrn",
    "medicalRecordNumber",
    "insuranceNumber",
    "labResult",
    "observation",
    "vitalSigns",
    "diagnoses",
    "diagnosisCode",
    "icd",
    "icdCode",
    "medications",
    "medicationName",
    "drug",
    "dosage",
    "prescriptions",
    "treatment",
    "procedureCode",
    "cptCode",
    "symptom",
    "symptoms",
    "disease",
    "illness",
    "disability",
    "medicalCondition",
    "healthCondition",
    "medicalHistory",
    "medicalRecord",
    "healthRecord",
    "clinicalNotes",
    "labResults",
    "bloodGroup",
    "vaccination",
    "immunization",
    "healthInsuranceNumber",
    "insuranceId",
    "npi",
    "deaNumber",
    "patientName",
    "patientDob"
  ],
  jsonKeyContains: ["diagnos", "medication", "prescription", "allerg", "patient"]
};

// src/rules/definitions/homePaths.ts
var USER_SEG = `[^/\\\\\\s"'<>]+`;
function validateHomeUser(match) {
  return match !== "." && match !== "..";
}
var homePathsRule = {
  id: "paths",
  label: "Home-directory usernames",
  description: "Only the username segment of a home-directory path is redacted (e.g. /home/jdoe/app \u2192 /home/<R:\u2026>/app); the rest of the path stays visible.",
  mode: "mask",
  token: "PATH",
  patterns: [
    `(?:/export/home/(${USER_SEG}))`,
    `(?:/usr/home/(${USER_SEG}))`,
    `(?:/var/home/(${USER_SEG}))`,
    `(?:/home/(${USER_SEG}))`,
    `(?:/Users/(${USER_SEG}))`,
    `(?:[A-Za-z]:\\\\Users\\\\(${USER_SEG}))`,
    `(?:[A-Za-z]:/Users/(${USER_SEG}))`,
    `(?:\\\\\\\\\\?\\\\[A-Za-z]:\\\\Users\\\\(${USER_SEG}))`,
    `(?:[A-Za-z]:\\\\Documents and Settings\\\\(${USER_SEG}))`,
    `(?:[A-Za-z]:\\\\\\\\Users\\\\\\\\(${USER_SEG}))`,
    `(?:/mnt/[A-Za-z]/Users/(${USER_SEG}))`,
    `(?://wsl\\$/(?:[A-Za-z0-9_-]+)/home/(${USER_SEG}))`
  ],
  validate: validateHomeUser
};

// src/rules/shared/windowsAccounts.ts
var BACKSLASH = "\\\\";
var JSON_BACKSLASH = "\\\\\\\\";
var WINDOWS_FILE_EXT = "exe|dll|sys|bat|cmd|ps1|vbs|msi|tmp|hiv|log|dat|txt|ini|xml|json|lnk|cpl|ocx|drv";
var NOT_WINDOWS_FILENAME = `(?![A-Za-z0-9_$.-]*\\.(?:${WINDOWS_FILE_EXT})(?![A-Za-z0-9]))`;
var WELL_KNOWN_DOMAIN = "(?:BUILTIN|NT SERVICE|NT AUTHORITY|Users|Settings|Files)";
var NETBIOS_DOMAIN = "[A-Za-z0-9](?:[A-Za-z0-9.-]{0,13}[A-Za-z0-9])?";
var ACCOUNT_SEGMENT = "[A-Za-z0-9_](?:[A-Za-z0-9_.$-]*[A-Za-z0-9$])";

// src/rules/definitions/hostnames.ts
var GTLD = [
  "abbott",
  "abogado",
  "ac",
  "academy",
  "accountant",
  "accountants",
  "active",
  "actor",
  "ad",
  "ads",
  "adult",
  "ae",
  "aero",
  "af",
  "afl",
  "ag",
  "agency",
  "ai",
  "airforce",
  "al",
  "allfinanz",
  "alsace",
  "am",
  "amsterdam",
  "an",
  "android",
  "ao",
  "apartments",
  "aq",
  "aquarelle",
  "ar",
  "archi",
  "army",
  "arpa",
  "as",
  "asia",
  "associates",
  "at",
  "attorney",
  "au",
  "auction",
  "audio",
  "autos",
  "aw",
  "ax",
  "axa",
  "az",
  "ba",
  "band",
  "bank",
  "bar",
  "barclaycard",
  "barclays",
  "bargains",
  "bauhaus",
  "bayern",
  "bb",
  "bbc",
  "bd",
  "be",
  "beer",
  "berlin",
  "best",
  "bf",
  "bg",
  "bh",
  "bi",
  "bid",
  "bike",
  "bingo",
  "bio",
  "biz",
  "bj",
  "bl",
  "black",
  "blackfriday",
  "bloomberg",
  "blue",
  "bm",
  "bmw",
  "bn",
  "bnpparibas",
  "bo",
  "boats",
  "bond",
  "boo",
  "boutique",
  "bq",
  "br",
  "brussels",
  "bs",
  "bt",
  "budapest",
  "build",
  "builders",
  "business",
  "buzz",
  "bv",
  "bw",
  "by",
  "bz",
  "bzh",
  "ca",
  "cab",
  "cafe",
  "cal",
  "camera",
  "camp",
  "cancerresearch",
  "canon",
  "capetown",
  "capital",
  "caravan",
  "cards",
  "care",
  "career",
  "careers",
  "cartier",
  "casa",
  "cash",
  "casino",
  "cat",
  "catering",
  "cbn",
  "cc",
  "cd",
  "center",
  "ceo",
  "cern",
  "cf",
  "cfd",
  "cg",
  "ch",
  "channel",
  "chat",
  "cheap",
  "chloe",
  "christmas",
  "chrome",
  "church",
  "ci",
  "citic",
  "city",
  "ck",
  "cl",
  "claims",
  "cleaning",
  "click",
  "clinic",
  "clothing",
  "club",
  "cm",
  "cn",
  "co",
  "coach",
  "codes",
  "coffee",
  "college",
  "cologne",
  "com",
  "community",
  "company",
  "computer",
  "condos",
  "construction",
  "consulting",
  "contractors",
  "cooking",
  "cool",
  "coop",
  "country",
  "courses",
  "cr",
  "credit",
  "creditcard",
  "cricket",
  "crs",
  "cruises",
  "cu",
  "cuisinella",
  "cv",
  "cw",
  "cx",
  "cy",
  "cymru",
  "cyou",
  "cz",
  "dabur",
  "dad",
  "dance",
  "date",
  "dating",
  "datsun",
  "day",
  "dclk",
  "de",
  "deals",
  "degree",
  "delivery",
  "democrat",
  "dental",
  "dentist",
  "desi",
  "design",
  "dev",
  "diamonds",
  "diet",
  "digital",
  "direct",
  "directory",
  "discount",
  "dj",
  "dk",
  "dm",
  "dnp",
  "do",
  "docs",
  "doha",
  "domains",
  "doosan",
  "download",
  "durban",
  "dvag",
  "dz",
  "eat",
  "ec",
  "edu",
  "education",
  "ee",
  "eg",
  "eh",
  "email",
  "emerck",
  "energy",
  "engineer",
  "engineering",
  "enterprises",
  "epson",
  "equipment",
  "er",
  "erni",
  "es",
  "esq",
  "estate",
  "et",
  "eu",
  "eurovision",
  "eus",
  "events",
  "everbank",
  "exchange",
  "expert",
  "exposed",
  "express",
  "fail",
  "faith",
  "fan",
  "fans",
  "farm",
  "fashion",
  "feedback",
  "fi",
  "film",
  "finance",
  "financial",
  "firmdale",
  "fish",
  "fishing",
  "fit",
  "fitness",
  "fj",
  "fk",
  "flights",
  "florist",
  "flowers",
  "flsmidth",
  "fly",
  "fm",
  "fo",
  "foo",
  "football",
  "forex",
  "forsale",
  "foundation",
  "fr",
  "frl",
  "frogans",
  "fund",
  "furniture",
  "futbol",
  "ga",
  "gal",
  "gallery",
  "garden",
  "gb",
  "gbiz",
  "gd",
  "gdn",
  "ge",
  "gent",
  "gf",
  "gg",
  "ggee",
  "gh",
  "gi",
  "gift",
  "gifts",
  "gives",
  "gl",
  "glass",
  "gle",
  "global",
  "globo",
  "gm",
  "gmail",
  "gmo",
  "gmx",
  "gn",
  "gold",
  "goldpoint",
  "golf",
  "goo",
  "goog",
  "google",
  "gop",
  "gov",
  "gp",
  "gq",
  "gr",
  "graphics",
  "gratis",
  "green",
  "gripe",
  "gs",
  "gt",
  "gu",
  "guge",
  "guide",
  "guitars",
  "guru",
  "gw",
  "gy",
  "hamburg",
  "hangout",
  "haus",
  "healthcare",
  "help",
  "here",
  "hermes",
  "hiphop",
  "hiv",
  "hk",
  "hm",
  "hn",
  "holdings",
  "holiday",
  "homes",
  "horse",
  "host",
  "hosting",
  "house",
  "how",
  "hr",
  "ht",
  "hu",
  "ibm",
  "id",
  "ie",
  "ifm",
  "il",
  "im",
  "immo",
  "immobilien",
  "in",
  "industries",
  "infiniti",
  "info",
  "ing",
  "ink",
  "institute",
  "insure",
  "int",
  "international",
  "investments",
  "io",
  "iq",
  "ir",
  "irish",
  "is",
  "it",
  "iwc",
  "java",
  "jcb",
  "je",
  "jetzt",
  "jm",
  "jo",
  "jobs",
  "joburg",
  "jp",
  "juegos",
  "kaufen",
  "kddi",
  "ke",
  "kg",
  "kh",
  "ki",
  "kim",
  "kitchen",
  "kiwi",
  "km",
  "kn",
  "koeln",
  "komatsu",
  "kp",
  "kr",
  "krd",
  "kred",
  "kw",
  "ky",
  "kyoto",
  "kz",
  "la",
  "lacaixa",
  "land",
  "lat",
  "latrobe",
  "lawyer",
  "lb",
  "lc",
  "lds",
  "lease",
  "leclerc",
  "legal",
  "lgbt",
  "li",
  "lidl",
  "life",
  "lighting",
  "limited",
  "limo",
  "link",
  "lk",
  "loan",
  "loans",
  "london",
  "lotte",
  "lotto",
  "love",
  "lr",
  "ls",
  "lt",
  "ltda",
  "lu",
  "luxe",
  "luxury",
  "lv",
  "ly",
  "ma",
  "madrid",
  "maif",
  "maison",
  "management",
  "mango",
  "market",
  "marketing",
  "markets",
  "marriott",
  "mc",
  "md",
  "me",
  "media",
  "meet",
  "melbourne",
  "meme",
  "memorial",
  "menu",
  "mf",
  "mg",
  "mh",
  "miami",
  "mil",
  "mini",
  "mk",
  "ml",
  "mm",
  "mma",
  "mn",
  "mo",
  "mobi",
  "moda",
  "moe",
  "monash",
  "money",
  "mormon",
  "mortgage",
  "moscow",
  "motorcycles",
  "mov",
  "movie",
  "mp",
  "mq",
  "mr",
  "ms",
  "mt",
  "mtn",
  "mtpc",
  "mu",
  "museum",
  "mv",
  "mw",
  "mx",
  "my",
  "mz",
  "na",
  "nagoya",
  "name",
  "navy",
  "nc",
  "ne",
  "net",
  "network",
  "neustar",
  "new",
  "news",
  "nexus",
  "nf",
  "ng",
  "ngo",
  "nhk",
  "ni",
  "nico",
  "ninja",
  "nissan",
  "nl",
  "no",
  "np",
  "nr",
  "nra",
  "nrw",
  "ntt",
  "nu",
  "nyc",
  "nz",
  "okinawa",
  "om",
  "one",
  "ong",
  "onl",
  "online",
  "ooo",
  "org",
  "organic",
  "osaka",
  "otsuka",
  "ovh",
  "pa",
  "page",
  "panerai",
  "paris",
  "partners",
  "parts",
  "party",
  "pe",
  "pf",
  "pg",
  "ph",
  "pharmacy",
  "photo",
  "photography",
  "photos",
  "physio",
  "piaget",
  "pics",
  "pictet",
  "pictures",
  "pink",
  "pizza",
  "pk",
  "pl",
  "place",
  "plumbing",
  "plus",
  "pm",
  "pn",
  "pohl",
  "poker",
  "porn",
  "post",
  "pr",
  "praxi",
  "press",
  "pro",
  "prod",
  "productions",
  "prof",
  "properties",
  "property",
  "ps",
  "pt",
  "pub",
  "pw",
  "py",
  "qa",
  "qpon",
  "quebec",
  "racing",
  "re",
  "realtor",
  "recipes",
  "red",
  "redstone",
  "rehab",
  "reise",
  "reisen",
  "reit",
  "ren",
  "rentals",
  "repair",
  "report",
  "republican",
  "rest",
  "restaurant",
  "review",
  "reviews",
  "rich",
  "rio",
  "rip",
  "ro",
  "rocks",
  "rodeo",
  "rs",
  "rsvp",
  "ru",
  "ruhr",
  "rw",
  "ryukyu",
  "sa",
  "saarland",
  "sale",
  "samsung",
  "sap",
  "sarl",
  "saxo",
  "sb",
  "sc",
  "sca",
  "scb",
  "schmidt",
  "scholarships",
  "school",
  "schule",
  "schwarz",
  "science",
  "scot",
  "sd",
  "se",
  "services",
  "sew",
  "sexy",
  "sg",
  "sh",
  "shiksha",
  "shoes",
  "shriram",
  "si",
  "singles",
  "site",
  "sj",
  "sk",
  "sky",
  "sl",
  "sm",
  "sn",
  "so",
  "social",
  "software",
  "sohu",
  "solar",
  "solutions",
  "soy",
  "space",
  "spiegel",
  "spreadbetting",
  "sr",
  "ss",
  "st",
  "study",
  "style",
  "su",
  "sucks",
  "supplies",
  "supply",
  "support",
  "surf",
  "surgery",
  "suzuki",
  "sv",
  "sx",
  "sy",
  "sydney",
  "systems",
  "sz",
  "taipei",
  "tatar",
  "tattoo",
  "tax",
  "tc",
  "td",
  "tech",
  "technology",
  "tel",
  "temasek",
  "tennis",
  "tf",
  "tg",
  "th",
  "tickets",
  "tienda",
  "tips",
  "tires",
  "tirol",
  "tj",
  "tk",
  "tl",
  "tm",
  "tn",
  "to",
  "today",
  "tokyo",
  "tools",
  "top",
  "toshiba",
  "tours",
  "town",
  "toys",
  "tp",
  "tr",
  "trade",
  "trading",
  "training",
  "travel",
  "trust",
  "tt",
  "tui",
  "tv",
  "tw",
  "tz",
  "ua",
  "ug",
  "uk",
  "um",
  "university",
  "uno",
  "uol",
  "us",
  "uy",
  "uz",
  "va",
  "vacations",
  "vc",
  "ve",
  "vegas",
  "ventures",
  "versicherung",
  "vet",
  "vg",
  "vi",
  "viajes",
  "video",
  "villas",
  "vision",
  "vlaanderen",
  "vn",
  "vodka",
  "vote",
  "voting",
  "voto",
  "voyage",
  "vu",
  "wales",
  "wang",
  "watch",
  "webcam",
  "website",
  "wed",
  "wedding",
  "wf",
  "whoswho",
  "wien",
  "wiki",
  "williamhill",
  "win",
  "wme",
  "work",
  "works",
  "world",
  "ws",
  "wtc",
  "wtf",
  "xin",
  "\u6D4B\u8BD5",
  "\u092A\u0930\u0940\u0915\u094D\u0937\u093E",
  "\u4F5B\u5C71",
  "\u6148\u5584",
  "\u96C6\u56E2",
  "\u5728\u7EBF",
  "\uD55C\uAD6D",
  "\u09AD\u09BE\u09B0\u09A4",
  "\u516B\u5366",
  "\u0645\u0648\u0642\u0639",
  "\u09AC\u09BE\u0982\u09B2\u09BE",
  "\u516C\u76CA",
  "\u516C\u53F8",
  "\u79FB\u52A8",
  "\u6211\u7231\u4F60",
  "\u043C\u043E\u0441\u043A\u0432\u0430",
  "\u0438\u0441\u043F\u044B\u0442\u0430\u043D\u0438\u0435",
  "\u049B\u0430\u0437",
  "\u043E\u043D\u043B\u0430\u0439\u043D",
  "\u0441\u0430\u0439\u0442",
  "\u0441\u0440\u0431",
  "\u0431\u0435\u043B",
  "\u65F6\u5C1A",
  "\uD14C\uC2A4\uD2B8",
  "\u6DE1\u9A6C\u9521",
  "\u043E\u0440\u0433",
  "\uC0BC\uC131",
  "\u0B9A\u0BBF\u0B99\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0BC2\u0BB0\u0BCD",
  "\u5546\u6807",
  "\u5546\u5E97",
  "\u5546\u57CE",
  "\u0434\u0435\u0442\u0438",
  "\u043C\u043A\u0434",
  "\u05D8\u05E2\u05E1\u05D8",
  "\u4E2D\u6587\u7F51",
  "\u4E2D\u4FE1",
  "\u4E2D\u56FD",
  "\u4E2D\u570B",
  "\u8C37\u6B4C",
  "\u0C2D\u0C3E\u0C30\u0C24\u0C4D",
  "\u0DBD\u0D82\u0D9A\u0DCF",
  "\u6E2C\u8A66",
  "\u0AAD\u0ABE\u0AB0\u0AA4",
  "\u092D\u093E\u0930\u0924",
  "\u0622\u0632\u0645\u0627\u06CC\u0634\u06CC",
  "\u0BAA\u0BB0\u0BBF\u0B9F\u0BCD\u0B9A\u0BC8",
  "\u7F51\u5E97",
  "\u0938\u0902\u0917\u0920\u0928",
  "\u7F51\u7EDC",
  "\u0443\u043A\u0440",
  "\u9999\u6E2F",
  "\u03B4\u03BF\u03BA\u03B9\u03BC\u03AE",
  "\u98DE\u5229\u6D66",
  "\u0625\u062E\u062A\u0628\u0627\u0631",
  "\u53F0\u6E7E",
  "\u53F0\u7063",
  "\u624B\u673A",
  "\u043C\u043E\u043D",
  "\u0627\u0644\u062C\u0632\u0627\u0626\u0631",
  "\u0639\u0645\u0627\u0646",
  "\u0627\u06CC\u0631\u0627\u0646",
  "\u0627\u0645\u0627\u0631\u0627\u062A",
  "\u0628\u0627\u0632\u0627\u0631",
  "\u067E\u0627\u06A9\u0633\u062A\u0627\u0646",
  "\u0627\u0644\u0627\u0631\u062F\u0646",
  "\u0628\u06BE\u0627\u0631\u062A",
  "\u0627\u0644\u0645\u063A\u0631\u0628",
  "\u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629",
  "\u0633\u0648\u062F\u0627\u0646",
  "\u0639\u0631\u0627\u0642",
  "\u0645\u0644\u064A\u0633\u064A\u0627",
  "\u653F\u5E9C",
  "\u0634\u0628\u0643\u0629",
  "\u10D2\u10D4",
  "\u673A\u6784",
  "\u7EC4\u7EC7\u673A\u6784",
  "\u5065\u5EB7",
  "\u0E44\u0E17\u0E22",
  "\u0633\u0648\u0631\u064A\u0629",
  "\u0440\u0443\u0441",
  "\u0440\u0444",
  "\u062A\u0648\u0646\u0633",
  "\u307F\u3093\u306A",
  "\u30B0\u30FC\u30B0\u30EB",
  "\u4E16\u754C",
  "\u0A2D\u0A3E\u0A30\u0A24",
  "\u7F51\u5740",
  "\u6E38\u620F",
  "verm\xF6gensberater",
  "verm\xF6gensberatung",
  "\u4F01\u4E1A",
  "\u4FE1\u606F",
  "\u0645\u0635\u0631",
  "\u0642\u0637\u0631",
  "\u5E7F\u4E1C",
  "\u0B87\u0BB2\u0B99\u0BCD\u0B95\u0BC8",
  "\u0B87\u0BA8\u0BCD\u0BA4\u0BBF\u0BAF\u0BBE",
  "\u0570\u0561\u0575",
  "\u65B0\u52A0\u5761",
  "\u0641\u0644\u0633\u0637\u064A\u0646",
  "\u30C6\u30B9\u30C8",
  "\u653F\u52A1",
  "xxx",
  "xyz",
  "yachts",
  "yandex",
  "ye",
  "yodobashi",
  "yoga",
  "yokohama",
  "youtube",
  "yt",
  "za",
  "zm",
  "zone",
  "zuerich",
  "zw"
];
var INTERNAL_SUFFIXES = [
  "local",
  "internal",
  "intranet",
  "corp",
  "lan",
  "home",
  "localdomain",
  "arpa",
  "test",
  "invalid",
  "localhost"
];
var INTERNAL_COMPOUND_SUFFIXES = [
  "svc\\.cluster\\.local",
  "ec2\\.internal",
  "compute\\.internal"
];
var FILE_EXT_COLLISION_TLDS = [
  "ac",
  "am",
  "cc",
  "gs",
  "hiv",
  "in",
  "is",
  "it",
  "java",
  "la",
  "md",
  "ml",
  "pl",
  "py",
  "rs",
  "sh",
  "so",
  "tf"
];
var COLLISION_TLD_SET = new Set(FILE_EXT_COLLISION_TLDS);
var GTLD_UNRESTRICTED = GTLD.filter((tld) => !COLLISION_TLD_SET.has(tld));
var TLD_EXACT = [...INTERNAL_COMPOUND_SUFFIXES, ...GTLD_UNRESTRICTED, ...INTERNAL_SUFFIXES].join(
  "|"
);
var TLD_COLLISION = FILE_EXT_COLLISION_TLDS.join("|");
var LABEL = "[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?";
var HOST_EXACT = `(?:(?<![\\w.$-])(?<![^:/\\\\][/\\\\])(?:${LABEL}\\.)+(?:${TLD_EXACT})(?!\\.?\\w))`;
var HOST_COLLISION = `(?:(?:https?|sftp|ftps?|wss?)://(?:[^/@\\s]+@)?)((?:${LABEL}\\.)+(?:${TLD_COLLISION}))(?!\\.?\\w)`;
function uncComputerPattern(separator) {
  return `(?:${separator}${separator})([A-Za-z][A-Za-z0-9-]{0,14})(?=${separator}[A-Za-z0-9$])`;
}
var UNC_COMPUTER = uncComputerPattern(BACKSLASH);
var UNC_COMPUTER_JSON = uncComputerPattern(JSON_BACKSLASH);
var SPN_HOST = "(?:\\b[A-Za-z][A-Za-z0-9]*/)([A-Za-z0-9][A-Za-z0-9.-]*)(?=@[A-Z0-9.-]+\\b)";
var HOST_CTX_KEY = "(?:host|hostname|computer)";
var HOST_VALUE = "[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?";
var HOST_CTX = `(?:\\b${HOST_CTX_KEY}\\s*[=:]\\s*)(${HOST_VALUE})`;
function anyCase(word) {
  let pattern = "";
  for (const char of word) {
    const lower = char.toLowerCase();
    const upper = char.toUpperCase();
    pattern += lower === upper ? char : `[${lower}${upper}]`;
  }
  return pattern;
}
var QUOTED_DOMAIN_ACCOUNT = `(?:")(?!${WELL_KNOWN_DOMAIN}\\\\{1,2})(${NETBIOS_DOMAIN})(?=\\\\{1,2}${NOT_WINDOWS_FILENAME}${ACCOUNT_SEGMENT}")`;
var KEY_WORD = "[A-Za-z_]*";
var JSON_HOST_KEY = [
  `${KEY_WORD}${anyCase("computer")}${KEY_WORD}`,
  `${KEY_WORD}${anyCase("domain")}[_-]?${anyCase("name")}`,
  `${anyCase("host")}(?:[_-]?${anyCase("name")})?`,
  anyCase("fqdn"),
  anyCase("domain"),
  `${anyCase("server")}[_-]?${anyCase("name")}`,
  `${anyCase("node")}[_-]?${anyCase("name")}`,
  `${anyCase("dns")}[_-]?${anyCase("name")}`,
  `${anyCase("machine")}[_-]?${anyCase("name")}`,
  `${anyCase("target")}[_-]?${anyCase("host")}`
].join("|");
var HOST_JSON_CTX = `(?:"(?:${JSON_HOST_KEY})"\\s*:\\s*")(${HOST_VALUE})(?=")`;
var NETBIOS_AGGRESSIVE = "(?:\\b(?:WIN|DESKTOP)-[A-Z0-9]{7,10}\\b)";
var SYSLOG_MONTH = "(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)";
var SYSLOG_BSD_TS = `${SYSLOG_MONTH}\\s+\\d{1,2}\\s+\\d{2}:\\d{2}:\\d{2}`;
var SYSLOG_ISO_TS = "\\d{4}-\\d{2}-\\d{2}[T ]\\d{2}:\\d{2}:\\d{2}(?:\\.\\d+)?(?:Z|[+-]\\d{2}:?\\d{2})?";
var SYSLOG_HOST_NAME = `${LABEL}(?:\\.${LABEL})*`;
var SYSLOG_HOST_LOOKAHEAD = "(?=\\s+[A-Za-z][A-Za-z0-9_.@-]*(?:\\[\\d+\\])?:)";
var SYSLOG_HOST = `(?:(?:${SYSLOG_BSD_TS}|${SYSLOG_ISO_TS})\\s+)(${SYSLOG_HOST_NAME})${SYSLOG_HOST_LOOKAHEAD}`;
var INVENTORY_PREFIX = "(?:[Ss][Rr][Vv]|[Ww][Ee][Bb]|[Dd][Bb]|[Aa][Pp][Pp]|[Hh][Oo][Ss][Tt]|[Nn][Oo][Dd][Ee]|[Pp][Oo][Dd])";
var INVENTORY_HOST = `(?:\\b${INVENTORY_PREFIX}-[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*-\\d+\\b)`;
var hostnamesRule = {
  id: "hosts",
  label: "Hostnames & domains",
  description: "FQDNs, UNC computer names, Kerberos SPN hosts, quoted JSON host fields, the domain half of a quoted DOMAIN\\account value and syslog host fields become the same token everywhere within a session.",
  mode: "pseudo",
  token: "HOST",
  patterns: [
    HOST_EXACT,
    HOST_COLLISION,
    UNC_COMPUTER,
    UNC_COMPUTER_JSON,
    SPN_HOST,
    HOST_CTX,
    HOST_JSON_CTX,
    QUOTED_DOMAIN_ACCOUNT,
    SYSLOG_HOST
  ],
  aggressivePatterns: [NETBIOS_AGGRESSIVE, INVENTORY_HOST],
  jsonKeys: [
    "hostname",
    "host",
    "fqdn",
    "domain",
    "computer",
    "computerName",
    "serverName",
    "nodeName",
    "dnsName",
    "machineName",
    "targetHost",
    "remoteHost",
    "sourceHost",
    "destinationHost",
    "srcHost",
    "dstHost",
    "shost",
    "dhost",
    "clientHost",
    "hostFqdn",
    "workstation",
    "workstationName",
    "deviceName",
    "deviceHostname",
    "sni",
    "serverNameIndication",
    "tlsServerName",
    "virtualHost",
    "vhost",
    "httpHost",
    "xForwardedHost",
    "qname",
    "queryName",
    "dnsDomain",
    "smtpHost",
    "mailServer"
  ],
  jsonKeyContains: ["computer", "domainname", "hostname", "fqdn", "workstation"]
};

// src/rules/definitions/ipAddresses.ts
var IPV4_OCTET = "(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)";
var IPV4 = `(?:(?<![\\d.])\\b${IPV4_OCTET}(?:\\.${IPV4_OCTET}){3}\\b(?!\\.\\d))`;
var IPV6_SEG = "[0-9a-fA-F]{1,4}";
var IPV6_FULL = `(?:${IPV6_SEG}:){7}${IPV6_SEG}`;
var IPV6_COMPRESSED = `(?:(?:${IPV6_SEG}:){1,7}:|(?:${IPV6_SEG}:){1,6}:${IPV6_SEG}|(?:${IPV6_SEG}:){1,5}(?::${IPV6_SEG}){1,2}|(?:${IPV6_SEG}:){1,4}(?::${IPV6_SEG}){1,3}|(?:${IPV6_SEG}:){1,3}(?::${IPV6_SEG}){1,4}|(?:${IPV6_SEG}:){1,2}(?::${IPV6_SEG}){1,5}|${IPV6_SEG}:(?::${IPV6_SEG}){1,6}|:(?:(?::${IPV6_SEG}){1,7}|:))`;
var IPV4_MAPPED = `(?:::ffff:${IPV4})`;
var IPV6 = `(?:(?<![A-Za-z0-9])(?:${IPV4_MAPPED}|${IPV6_FULL}|${IPV6_COMPRESSED})(?![A-Za-z0-9:])(?!\\.\\d)(?:%[A-Za-z0-9_.-]+)?)`;
var PTR_V4 = "(?:\\b(?:\\d{1,3}\\.){4}in-addr\\.arpa\\b)";
var PTR_V6 = "(?:\\b(?:[0-9a-fA-F]\\.){4,32}ip6\\.arpa\\b)";
var MAC_COLON = "(?:(?<!&)\\b[0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5}\\b)";
var MAC_DASH = "(?:\\b[0-9A-Fa-f]{2}(?:-[0-9A-Fa-f]{2}){5}\\b)";
var MAC_CISCO = "(?:\\b[0-9A-Fa-f]{4}(?:\\.[0-9A-Fa-f]{4}){2}\\b)";
function ipv4ToOctets(ip) {
  return ip.split(".").map(Number);
}
function isNetmaskShape(octets) {
  const bin = octets.map((octet) => octet.toString(2).padStart(8, "0")).join("");
  return /^1*0*$/.test(bin);
}
function isReservedIpv4(ip) {
  const octets = ipv4ToOctets(ip);
  if (octets.length !== 4 || octets.some((octet) => Number.isNaN(octet))) {
    return false;
  }
  if (octets[0] === 127) {
    return true;
  }
  if (octets[0] === 0) {
    return true;
  }
  if (octets[0] === 169 && octets[1] === 254) {
    return true;
  }
  if (octets[0] >= 224 && octets[0] <= 239) {
    return true;
  }
  return isNetmaskShape(octets);
}
function validateIp(match) {
  if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(match)) {
    return !isReservedIpv4(match);
  }
  const withoutZone = match.split("%")[0] ?? match;
  if (withoutZone === "::" || withoutZone === "::1") {
    return false;
  }
  const mapped = /^::ffff:(\d{1,3}(?:\.\d{1,3}){3})$/.exec(withoutZone);
  if (mapped?.[1]) {
    return !isReservedIpv4(mapped[1]);
  }
  return true;
}
var ipAddressesRule = {
  id: "ips",
  label: "Network addresses",
  description: "IPv4/IPv6 addresses, MAC addresses and reverse-DNS (PTR) names become the same token everywhere within a session.",
  mode: "pseudo",
  token: "IP",
  patterns: [PTR_V4, PTR_V6, IPV6, IPV4, MAC_COLON, MAC_DASH, MAC_CISCO],
  validate: validateIp,
  jsonKeys: [
    "ip",
    "ipAddress",
    "ip_address",
    "clientIp",
    "remoteAddr",
    "srcIp",
    "dstIp",
    "sourceIp",
    "destinationIp",
    "xForwardedFor",
    "mac",
    "macAddress",
    "ipv4",
    "ipv6",
    "ipAddr",
    "clientAddress",
    "clientAddr",
    "serverAddress",
    "remoteIp",
    "remoteAddress",
    "peerIp",
    "peerAddress",
    "srcAddr",
    "dstAddr",
    "sourceAddress",
    "destinationAddress",
    "src",
    "dst",
    "srcIpAddr",
    "dstIpAddr",
    "localIp",
    "publicIp",
    "privateIp",
    "externalIp",
    "internalIp",
    "hostIp",
    "serverIp",
    "nasIpAddress",
    "callerIpAddress",
    "sourceIPAddress",
    "trueClientIp",
    "xRealIp",
    "cfConnectingIp",
    "forwardedFor",
    "natIp",
    "gatewayIp",
    "macAddr",
    "hwAddr",
    "clientMac",
    "srcMac",
    "dstMac",
    "smac",
    "dmac",
    "bssid"
  ],
  jsonKeyContains: [
    "ipaddr",
    "macaddr",
    "networkaddress",
    "remoteaddr",
    "clientaddr",
    "peeraddr",
    "clientip",
    "sourceip",
    "remoteip",
    "srcip",
    "dstip",
    "destinationip"
  ]
};

// src/rules/shared/hmacSha256.ts
var BLOCK_BYTES = 64;
var DIGEST_BYTES = 32;
var K = new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var INITIAL_STATE = new Uint32Array([
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
]);
function rotr(value, bits) {
  return (value >>> bits | value << 32 - bits) >>> 0;
}
function padMessage(message) {
  const bitLength = message.length * 8;
  const paddedLength = Math.ceil((message.length + 9) / BLOCK_BYTES) * BLOCK_BYTES;
  const padded = new Uint8Array(paddedLength);
  padded.set(message);
  padded[message.length] = 128;
  const view = new DataView(padded.buffer);
  view.setUint32(paddedLength - 8, Math.floor(bitLength / 2 ** 32), false);
  view.setUint32(paddedLength - 4, bitLength >>> 0, false);
  return padded;
}
function sha256(message) {
  const padded = padMessage(message);
  const view = new DataView(padded.buffer);
  const state = Uint32Array.from(INITIAL_STATE);
  const w = new Uint32Array(64);
  for (let offset = 0; offset < padded.length; offset += BLOCK_BYTES) {
    for (let i = 0; i < 16; i += 1) {
      w[i] = view.getUint32(offset + i * 4, false);
    }
    for (let i = 16; i < 64; i += 1) {
      const s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ w[i - 15] >>> 3;
      const s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ w[i - 2] >>> 10;
      w[i] = w[i - 16] + s0 + w[i - 7] + s1 >>> 0;
    }
    let [a, b, c, d, e, f, g, h] = state;
    for (let i = 0; i < 64; i += 1) {
      const s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
      const ch = e & f ^ ~e & g;
      const temp1 = h + s1 + ch + K[i] + w[i] >>> 0;
      const s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
      const maj = a & b ^ a & c ^ b & c;
      const temp2 = s0 + maj >>> 0;
      h = g;
      g = f;
      f = e;
      e = d + temp1 >>> 0;
      d = c;
      c = b;
      b = a;
      a = temp1 + temp2 >>> 0;
    }
    state[0] = state[0] + a >>> 0;
    state[1] = state[1] + b >>> 0;
    state[2] = state[2] + c >>> 0;
    state[3] = state[3] + d >>> 0;
    state[4] = state[4] + e >>> 0;
    state[5] = state[5] + f >>> 0;
    state[6] = state[6] + g >>> 0;
    state[7] = state[7] + h >>> 0;
  }
  const digest = new Uint8Array(DIGEST_BYTES);
  const digestView = new DataView(digest.buffer);
  for (let i = 0; i < 8; i += 1) {
    digestView.setUint32(i * 4, state[i], false);
  }
  return digest;
}

// src/rules/definitions/paymentInfo.ts
var BASE58_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
function luhnCheck2(digits) {
  if (!/^\d{13,19}$/.test(digits) || /^0+$/.test(digits)) {
    return false;
  }
  let sum = 0;
  let doubleIt = false;
  for (let i = digits.length - 1; i >= 0; i -= 1) {
    let digit = Number(digits[i]);
    if (doubleIt) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    sum += digit;
    doubleIt = !doubleIt;
  }
  return sum % 10 === 0;
}
function ibanMod97(iban) {
  const compact = iban.replace(/\s/g, "").toUpperCase();
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]{10,30}$/.test(compact)) {
    return false;
  }
  const rearranged = compact.slice(4) + compact.slice(0, 4);
  const numeric = rearranged.replace(/[A-Z]/g, (char) => String(char.charCodeAt(0) - 55));
  let remainder = 0;
  for (let i = 0; i < numeric.length; i += 1) {
    remainder = (remainder * 10 + Number(numeric[i])) % 97;
  }
  return remainder === 1;
}
var IBAN_COUNTRY_CODES = /* @__PURE__ */ new Set([
  "AD",
  "AE",
  "AL",
  "AO",
  "AT",
  "AZ",
  "BA",
  "BE",
  "BF",
  "BG",
  "BH",
  "BI",
  "BJ",
  "BR",
  "BY",
  "CF",
  "CG",
  "CH",
  "CI",
  "CM",
  "CR",
  "CV",
  "CY",
  "CZ",
  "DE",
  "DJ",
  "DK",
  "DO",
  "DZ",
  "EE",
  "EG",
  "ES",
  "FI",
  "FO",
  "FR",
  "GA",
  "GB",
  "GE",
  "GI",
  "GL",
  "GQ",
  "GR",
  "GT",
  "GW",
  "HN",
  "HR",
  "HU",
  "IE",
  "IL",
  "IQ",
  "IR",
  "IS",
  "IT",
  "JO",
  "KM",
  "KW",
  "KZ",
  "LB",
  "LC",
  "LI",
  "LT",
  "LU",
  "LV",
  "LY",
  "MA",
  "MC",
  "MD",
  "ME",
  "MG",
  "MK",
  "ML",
  "MR",
  "MT",
  "MU",
  "MZ",
  "NE",
  "NI",
  "NL",
  "NO",
  "PK",
  "PL",
  "PS",
  "PT",
  "QA",
  "RO",
  "RS",
  "RU",
  "SA",
  "SC",
  "SD",
  "SE",
  "SI",
  "SK",
  "SM",
  "SN",
  "ST",
  "SV",
  "TD",
  "TG",
  "TL",
  "TN",
  "TR",
  "UA",
  "VA",
  "VG",
  "XK"
]);
function isIbanCountry(compact) {
  return IBAN_COUNTRY_CODES.has(compact.slice(0, 2).toUpperCase());
}
function isHexHashLength(value) {
  return /^(?:[A-Fa-f0-9]{32}|[A-Fa-f0-9]{40}|[A-Fa-f0-9]{64})$/.test(value);
}
function isCardSeparatorLayout(match) {
  if (!/[ -]/.test(match)) {
    return true;
  }
  const groups = match.split(/[ -]/).map((group) => group.length);
  if (groups.some((length) => length === 0)) {
    return false;
  }
  if (groups.length === 3 && groups[0] === 4 && groups[1] === 6 && (groups[2] === 4 || groups[2] === 5)) {
    return true;
  }
  const last = groups[groups.length - 1];
  return groups.length >= 2 && groups.slice(0, -1).every((length) => length === 4) && last >= 1 && last <= 7;
}
function bitcoinBase58Check(address) {
  const decoded = decodeBase58(address);
  if (!decoded || decoded.length < 5) {
    return false;
  }
  const payload = decoded.subarray(0, decoded.length - 4);
  const checksum = decoded.subarray(decoded.length - 4);
  const digest = sha256(sha256(payload));
  return digest[0] === checksum[0] && digest[1] === checksum[1] && digest[2] === checksum[2] && digest[3] === checksum[3];
}
function decodeBase58(input) {
  const bytes = [0];
  for (let i = 0; i < input.length; i += 1) {
    let carry = BASE58_ALPHABET.indexOf(input[i]);
    if (carry === -1) {
      return null;
    }
    for (let j = 0; j < bytes.length; j += 1) {
      carry += bytes[j] * 58;
      bytes[j] = carry % 256;
      carry = Math.floor(carry / 256);
    }
    while (carry > 0) {
      bytes.push(carry % 256);
      carry = Math.floor(carry / 256);
    }
  }
  let leadingOnes = 0;
  while (leadingOnes < input.length && input[leadingOnes] === "1") {
    leadingOnes += 1;
  }
  let end = bytes.length;
  while (end > 0 && bytes[end - 1] === 0) {
    end -= 1;
  }
  const out = new Uint8Array(leadingOnes + end);
  for (let i = 0; i < end; i += 1) {
    out[leadingOnes + end - 1 - i] = bytes[i];
  }
  return out;
}
function isKnownCardIin(digits) {
  const { length } = digits;
  const d2 = Number(digits.slice(0, 2));
  const d4 = Number(digits.slice(0, 4));
  switch (digits[0]) {
    case "4":
      return length === 13 || length === 16 || length === 19;
    case "5":
      return length === 16 && d2 >= 51 && d2 <= 55;
    case "2":
      return length === 16 && d4 >= 2221 && d4 <= 2720;
    case "3":
      if (length === 15) {
        return d2 === 34 || d2 === 37;
      }
      if (length === 14) {
        return d2 === 36 || d2 === 38 || d2 === 39 || d4 >= 3e3 && d4 <= 3059 || d4 === 3095;
      }
      return length >= 16 && length <= 19 && d4 >= 3528 && d4 <= 3589;
    case "6":
      return length >= 16 && length <= 19 && (digits.startsWith("6011") || digits.startsWith("62") || digits.startsWith("64") || digits.startsWith("65"));
    default:
      return false;
  }
}
function validatePayment(match) {
  const compactIban = match.replace(/\s/g, "");
  if (/^[A-Za-z]{2}\d{2}[A-Za-z0-9]+$/.test(compactIban)) {
    return !isHexHashLength(compactIban) && isIbanCountry(compactIban) && ibanMod97(match);
  }
  const compactPan = match.replace(/[ -]/g, "");
  if (/^[\d -]+$/.test(match) && /^\d{13,19}$/.test(compactPan)) {
    const grouped = /[ -]/.test(match);
    if (!grouped && compactPan.length > 16) {
      return false;
    }
    return isCardSeparatorLayout(match) && isKnownCardIin(compactPan) && luhnCheck2(compactPan);
  }
  if (/^[13][A-HJ-NP-Za-km-z1-9]{25,34}$/.test(match)) {
    return bitcoinBase58Check(match);
  }
  return true;
}
var CVV_KEY = "(?:[Cc][Vv][Vv]2?|[Cc][Vv][Cc]2?|[Cc][Ii][Dd])";
var EXP_KEY = "(?:[Ee]xp(?:iry|iration)?|[Ee]xp[_-]?[Dd]ate)";
var ROUTING_KEY = "(?:[Rr]outing(?:[_-]?[Nn]umber)?|[Aa][Bb][Aa])";
var ACCOUNT_KEY = "(?:[Aa]ccount[_-]?[Nn]umber|[Aa]cct)";
var paymentInfoRule = {
  id: "paymentInfo",
  label: "Payment info",
  description: "IBANs, card numbers (PAN, Luhn-checked), CVV/CVC, expiry dates and crypto addresses are redacted outright.",
  mode: "mask",
  token: "PAYMENT",
  patterns: [
    "(?:(?<![.\\d])\\b\\d(?:[ -]?\\d){12,18}\\b)",
    "(?:\\b[A-Z]{2}\\d{2}[A-Z0-9]{10,30}\\b)",
    "(?:\\b[A-Z]{2}\\d{2}(?: [A-Z0-9]{4}){2,7}(?: [A-Z0-9]{1,4})?\\b)",
    `(?:\\b${CVV_KEY}\\s*[=:]\\s*)(\\d{3,4}\\b)`,
    `(?:\\b${EXP_KEY}\\s*[=:]\\s*)((?:0[1-9]|1[0-2])[/-](?:\\d{2}|\\d{4})\\b)`,
    "(?:\\bbc1[a-z0-9]{25,39}\\b)",
    "(?:(?<![A-Za-z0-9])[13][A-HJ-NP-Za-km-z1-9]{25,34}(?![A-Za-z0-9]))",
    "(?:\\b0x[A-Fa-f0-9]{40}\\b)"
  ],
  aggressivePatterns: [
    "(?:(?<![\\\\/])\\b[A-Z]{6}[A-Z0-9]{2}(?:[A-Z0-9]{3})?\\b(?![\\\\/]))",
    `(?:\\b${ROUTING_KEY}\\s*[=:]\\s*)(\\d{9}\\b)`,
    `(?:\\b${ACCOUNT_KEY}\\s*[=:]\\s*)(\\d{8,12}\\b)`
  ],
  validate: validatePayment,
  jsonKeys: [
    "iban",
    "cardNumber",
    "pan",
    "cvv",
    "cvc",
    "card_number",
    "creditCard",
    "cvv2",
    "accountNumber",
    "routingNumber",
    "bic",
    "swift",
    "expiryDate",
    "ccNumber",
    "cardNo",
    "cardNum",
    "creditCardNumber",
    "debitCardNumber",
    "primaryAccountNumber",
    "cvc2",
    "cvn",
    "csc",
    "securityCode",
    "cardSecurityCode",
    "cardCvv",
    "cardExpiry",
    "expDate",
    "expirationDate",
    "bankAccount",
    "bankAccountNumber",
    "acctNumber",
    "sortCode",
    "bsb",
    "swiftCode",
    "bicCode",
    "ibanNumber",
    "walletAddress",
    "btcAddress",
    "ethAddress",
    "cardHolder",
    "cardholderName",
    "nameOnCard",
    "track1",
    "track2",
    "trackData"
  ],
  jsonKeyContains: ["iban", "cardnumber", "cvv", "creditcard", "accountnumber"]
};

// src/rules/definitions/phoneNumbers.ts
function validatePhone(match) {
  const digits = match.replace(/\D/g, "");
  const national = digits.startsWith("00") ? digits.slice(2) : digits;
  return national.length >= 7 && national.length <= 15;
}
var PHONE_KEY = "(?:telephone|phone|mobile|msisdn|cell|fax|tel)";
var phoneNumbersRule = {
  id: "phoneNumbers",
  label: "Phone numbers",
  description: "Phone numbers become a stable <PHONE:\u2026> token \u2014 the same number maps to the same token everywhere within a session.",
  mode: "pseudo",
  token: "PHONE",
  patterns: [
    "(?:(?<![A-Za-z0-9])\\+[1-9](?:[\\s().-]*\\d){6,14}(?!\\d))",
    "(?:\\(\\d{3}\\)\\s?\\d{3}-\\d{4}(?!\\d))",
    "(?:\\b\\d{3}-\\d{3}-\\d{4}\\b)",
    "(?:\\b1-\\d{3}-\\d{3}-\\d{4}\\b)",
    "(?:\\b0\\d{2}-\\d{3}-\\d{2}-\\d{2}\\b)",
    "(?:\\b0\\d{2}\\s\\d{3}\\s\\d{2}\\s\\d{2}\\b)",
    "(?:(?<![.\\d-])\\b00[1-9](?:[\\s().-]*\\d){7,13}(?!\\w)(?!-[\\dA-Fa-f]))",
    "(?:\\b(?:tel|sms):)(\\+?[1-9](?:[\\s().-]*\\d){6,14})(?!\\d)",
    `(?:\\b${PHONE_KEY}\\s*[=:]\\s*)(\\+?[0-9](?:[\\s().-]*\\d){6,14})(?!\\d)`
  ],
  validate: validatePhone,
  jsonKeys: [
    "phone",
    "phoneNumber",
    "phone_number",
    "mobile",
    "mobileNumber",
    "cell",
    "telephone",
    "tel",
    "fax",
    "msisdn",
    "contactNumber",
    "phoneNo",
    "phoneNum",
    "mobilePhone",
    "mobileNo",
    "cellPhone",
    "homePhone",
    "workPhone",
    "businessPhone",
    "telephoneNumber",
    "otherTelephone",
    "telNo",
    "faxNumber",
    "contactPhone",
    "primaryPhone",
    "callerId",
    "callerNumber",
    "callingNumber",
    "calledNumber",
    "ani",
    "dnis",
    "whatsapp"
  ],
  jsonKeyContains: ["phone", "msisdn", "mobilenumber", "faxnumber"]
};

// src/rules/definitions/secrets.ts
var ENTROPY_THRESHOLD = 3.5;
function shannonEntropy(value) {
  const { length } = value;
  if (length === 0) {
    return 0;
  }
  const freq = {};
  for (let i = 0; i < length; i += 1) {
    const char = value[i];
    freq[char] = (freq[char] ?? 0) + 1;
  }
  return Object.values(freq).reduce((entropy, count) => {
    const p = count / length;
    return entropy - p * Math.log2(p);
  }, 0);
}
function isHexBlob(match) {
  return match.length >= 32 && /^[A-Fa-f0-9]+$/.test(match);
}
function isBase64Blob(match) {
  return match.length >= 40 && /^[A-Za-z0-9+/]+=*$/.test(match);
}
function validateSecret(match) {
  if (isHexBlob(match)) {
    return shannonEntropy(match) > ENTROPY_THRESHOLD;
  }
  if (isBase64Blob(match)) {
    return shannonEntropy(match) > ENTROPY_THRESHOLD && /[A-Za-z]/.test(match) && /[0-9+/]/.test(match);
  }
  return true;
}
var CONTEXT_KEYS = "(?:api[_-]?key|apikey|access[_-]?token|refresh[_-]?token|id[_-]?token|client[_-]?secret|secret[_-]?key|private[_-]?key|password|passwd|pwd|pass|auth[_-]?token|signing[_-]?key)";
var CONTEXT_VALUE = `[^\\s,;}"']{4,}`;
var CLI_FLAGS = "(?:password|secret|token|api-key|apikey|access-token|client-secret)";
var secretsRule = {
  id: "secrets",
  label: "Tokens & credentials",
  description: "Bearer tokens, JWTs and API keys are redacted outright \u2014 they are not meant to be traced.",
  mode: "mask",
  token: "SECRET",
  patterns: [
    "(?:(?:Bearer|bearer|BEARER)\\s+)([A-Za-z0-9._\\-+/=]{8,})",
    "(?:(?:Basic|basic|BASIC)\\s+)([A-Za-z0-9+/]{8,}={0,2})",
    "(?:(?<![A-Za-z0-9_-])eyJ[A-Za-z0-9_-]{8,}\\.[A-Za-z0-9_-]{8,}(?:\\.[A-Za-z0-9_-]{8,})?)",
    "(?:-----BEGIN (?:(?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY|CERTIFICATE)-----[A-Za-z0-9+/=\\s\\\\]+?-----END (?:(?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY|CERTIFICATE)-----)",
    "(?:\\b(?:AKIA|ASIA|ABIA|ACCA)[A-Z0-9]{16}\\b)",
    "(?:(?:aws_secret_access_key|AWS_SECRET_ACCESS_KEY)\\s*[=:]\\s*)([A-Za-z0-9/+=]{30,})",
    "(?:github_pat_[A-Za-z0-9_]{22,})",
    "(?:gh[pousr]_[A-Za-z0-9]{36,})",
    "(?:xox[abprs]-[A-Za-z0-9-]{10,})",
    "(?:hooks\\.slack\\.com/services/[A-Za-z0-9/_-]{16,})",
    "(?:AIza[A-Za-z0-9_-]{35})",
    "(?:(?:sk_live_|sk_test_|rk_live_|rk_test_)[A-Za-z0-9]{16,})",
    "(?:sk-proj-[A-Za-z0-9_-]{16,})",
    "(?:sk-[A-Za-z0-9]{20,})",
    // Kept as a lookbehind: `.{0,60}` asserts a nearby keyword rather than an adjacent prefix, so
    // one `Twilio` has to stay reusable by every identifier that follows it.
    "(?:(?<=(?:[Tt]wilio.{0,60}|\\b(?:[Aa]ccount[Ss]id|[Aa]uth[Tt]oken|[Ss]id)\\s*[=:]\\s*))(?:AC|SK)[0-9A-Fa-f]{32})",
    "(?:SG\\.[A-Za-z0-9_-]{10,}\\.[A-Za-z0-9_-]{10,})",
    "(?:npm_[A-Za-z0-9]{36,})",
    `(?:[?&][Ss]ig=)([^&\\s"']{16,})`,
    "(?:[a-zA-Z][a-zA-Z0-9+.-]*://)([^/@\\s:]+:[^/@\\s]+@)",
    `(?:--${CLI_FLAGS}(?:\\s+|=)"?)([^\\s"']{4,})`,
    `(?:\\b${CONTEXT_KEYS}"?\\s*[=:]\\s*"?)(${CONTEXT_VALUE})`
  ],
  aggressivePatterns: [
    "(?:(?<![A-Za-z0-9+/])[A-Za-z0-9+/]{40,}={0,2}(?![A-Za-z0-9+/=]))",
    "(?:\\b[A-Fa-f0-9]{32,}\\b)"
  ],
  validate: validateSecret,
  jsonKeys: [
    "password",
    "token",
    "authorization",
    "apiKey",
    "secret",
    "accessToken",
    "refreshToken",
    "passwd",
    "pwd",
    "pass",
    "clientSecret",
    "privateKey",
    "secretKey",
    "apiSecret",
    "credentials",
    "auth",
    "xApiKey",
    "idToken",
    "awsSecretAccessKey",
    "signature",
    "accessKey",
    "accessKeyId",
    "secretAccessKey",
    "awsSessionToken",
    "xAmzSecurityToken",
    "bearerToken",
    "authToken",
    "authKey",
    "apiToken",
    "appSecret",
    "consumerSecret",
    "oauthToken",
    "oauthTokenSecret",
    "masterKey",
    "encryptionKey",
    "sharedKey",
    "sharedSecret",
    "webhookSecret",
    "signingSecret",
    "signingKey",
    "connectionString",
    "connStr",
    "passphrase",
    "passwordHash",
    "pwdHash",
    "otp",
    "totp",
    "mfaCode",
    "oneTimePassword",
    "verificationCode",
    "recoveryCode",
    "sshKey",
    "subscriptionKey",
    "ocpApimSubscriptionKey",
    "xAuthToken",
    "xAccessToken",
    "proxyAuthorization",
    "sasToken",
    "vaultToken",
    "xVaultToken",
    "jwt",
    "samlResponse",
    "samlAssertion",
    "pinBlock"
  ],
  jsonKeyContains: [
    "password",
    "passwd",
    "secret",
    "apikey",
    "accesstoken",
    "refreshtoken",
    "idtoken",
    "authtoken",
    "bearertoken",
    "privatekey",
    "credential",
    "passphrase",
    "connectionstring"
  ]
};

// src/rules/definitions/sessionCookies.ts
var COOKIE_VALUE = "[^;\\s]{8,}";
var sessionCookiesRule = {
  id: "sessionCookies",
  label: "Session cookies",
  description: "Session identifiers (sessionid, sid, JSESSIONID, PHPSESSID) are redacted outright.",
  mode: "mask",
  token: "SESSION",
  patterns: [
    `(?:(?<![\\w-])(?:[Ss]essionid|[Ss]ession_id|sessionId|SESSIONID)=${COOKIE_VALUE})`,
    `(?:(?<![\\w-])sid=${COOKIE_VALUE})`,
    `(?:PHPSESSID=${COOKIE_VALUE})`,
    `(?:JSESSIONID=${COOKIE_VALUE})`,
    `(?:ASP\\.NET_SessionId=${COOKIE_VALUE})`,
    `(?:ASPSESSIONID[A-Za-z0-9]*=${COOKIE_VALUE})`,
    `(?:connect\\.sid=${COOKIE_VALUE})`,
    `(?:laravel_session=${COOKIE_VALUE})`,
    `(?:_session_id=${COOKIE_VALUE})`,
    `(?:(?:csrftoken|csrf_token|XSRF-TOKEN|xsrf-token)=${COOKIE_VALUE})`,
    `(?:remember_token=${COOKIE_VALUE})`,
    `(?:(?:SSESS|SESS)[A-Fa-f0-9]{32}=${COOKIE_VALUE})`,
    `(?:[Ss]et-[Cc]ookie:\\s*)([^;=\\s]+=${COOKIE_VALUE})`
  ],
  aggressivePatterns: [
    `(?:(?<![\\w-])[\\w-]*session[\\w-]*=${COOKIE_VALUE})`,
    `(?:(?<![\\w-])[\\w-]*token=${COOKIE_VALUE})`
  ],
  jsonKeys: [
    "sessionId",
    "sid",
    "cookie",
    "cookies",
    "setCookie",
    "jsessionid",
    "csrfToken",
    "sessionCookie",
    "sessionToken",
    "sessionKey",
    "session",
    "phpsessid",
    "aspNetSessionId",
    "connectSid",
    "laravelSession",
    "xsrfToken",
    "xCsrfToken",
    "xXsrfToken",
    "csrf",
    "rememberToken",
    "authCookie",
    "cookieHeader",
    "requestCookies",
    "responseCookies"
  ],
  jsonKeyContains: [
    "sessionid",
    "sessiontoken",
    "sessioncookie",
    "sessionkey",
    "cookie",
    "csrf",
    "xsrf"
  ]
};

// src/rules/definitions/users.ts
var EMAIL_LOCAL = "[A-Za-z0-9._%+-]+";
var EMAIL_DOMAIN = "[A-Za-z0-9.-]+\\.[A-Za-z]{2,}";
var EMAIL = `(?:\\b${EMAIL_LOCAL}@${EMAIL_DOMAIN})`;
var EMAIL_IP_LITERAL = `(?:\\b${EMAIL_LOCAL}@\\[[0-9a-fA-F.:]+\\])`;
var USER_SEG_SIMPLE = ACCOUNT_SEGMENT;
var NOT_GUID = "(?![0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-)";
var ACCOUNT_END = "(?![A-Za-z0-9_$\\\\/-])";
function domainUserPattern(separator) {
  const winDomainExclude = `${WELL_KNOWN_DOMAIN}${separator}`;
  const pathRoot = `(?:\\b(?:HKLM|HKCU|HKU|HKCR|HKEY_[A-Z_]+)|\\b[A-Za-z]:)${separator}`;
  const notUnderPathRoot = `(?<!${pathRoot}(?:(?! [-/])[^<>'"\\n])*)`;
  const domain = `(?:^|[^\\\\.-])\\b${NETBIOS_DOMAIN}${separator}`;
  return `(?:(?:${domain})(?<!${winDomainExclude})${NOT_WINDOWS_FILENAME}${NOT_GUID}(${USER_SEG_SIMPLE})${ACCOUNT_END}${notUnderPathRoot})`;
}
var DOMAIN_USER = domainUserPattern(BACKSLASH);
var DOMAIN_USER_JSON = domainUserPattern(JSON_BACKSLASH);
var SID = "(?:\\bS-1-(?:\\d+-){1,14}\\d+\\b)";
var VALUE_WITH_LETTER = "[\\w.@+-]*[A-Za-z][\\w.@+-]*";
var LDAP_DN_SINGLE = `(?:\\b(?:uid|sAMAccountName)=)(${VALUE_WITH_LETTER})`;
var CN_VALUE = "(?:[A-Za-z0-9.'-]+(?: [A-Za-z0-9.'-]+){0,3})";
var LDAP_DN_CN = `(?:\\bcn=)(${CN_VALUE})`;
var ARN_USER = "(?::user/)([\\w.@+=,-]+)";
var ARN_ASSUMED_ROLE_SESSION = "(?::assumed-role/[\\w+=,.@-]+/)([\\w.@+=,-]+)";
var K8S_SERVICE_ACCOUNT = "(?:\\bsystem:serviceaccount:[A-Za-z0-9-]+:)([A-Za-z0-9-]+)";
var SSHD_FOR_USER = "(?:(?:\\bfor (?:invalid )?user|\\b[Ii]nvalid user)\\s+)([A-Za-z0-9._-]+)";
var SSHD_RUSER = "(?:\\bruser=)([A-Za-z0-9._-]+)";
var SSHD_LOGNAME = "(?:\\blogname=)([A-Za-z0-9._-]+)";
var SUDO_USER = "(?:\\bsudo:\\s+)([A-Za-z0-9._-]+)(?=\\s+:)";
var GENERIC_KEY = "(?:user|username|login|account|owner|actor|principal|requester|createdBy|modifiedBy|assignee|operator)";
var GENERIC_CTX = `(?:\\b${GENERIC_KEY}\\s*[=:]\\s*)(${VALUE_WITH_LETTER})`;
var SLACK_USER_ID_AGGRESSIVE = "(?:\\bU[A-Z0-9]{8,10}\\b)";
var SYSTEM_ACCOUNTS = /* @__PURE__ */ new Set([
  "root",
  "system",
  "daemon",
  "nobody",
  "www-data",
  "nginx",
  "sshd",
  "syslog"
]);
function isWellKnownWindowsAccount(match) {
  const upper = match.toUpperCase();
  if (upper === "SYSTEM" || upper === "LOCAL" || upper === "NETWORK" || upper === "ANONYMOUS") {
    return true;
  }
  return match.endsWith("$");
}
function isWellKnownSid(match) {
  if (match === "S-1-1-0") {
    return true;
  }
  if (/^S-1-5-(?:18|19|20)$/.test(match)) {
    return true;
  }
  return /^S-1-5-32-\d+$/.test(match);
}
function validateUser(match) {
  if (isWellKnownWindowsAccount(match)) {
    return false;
  }
  if (isWellKnownSid(match)) {
    return false;
  }
  return !SYSTEM_ACCOUNTS.has(match.toLowerCase());
}
var usersRule = {
  id: "users",
  label: "Usernames & emails",
  description: "Email addresses and account identifiers (DOMAIN\\user, SIDs, ARNs, LDAP DNs, sshd/PAM context) become the same token everywhere within a session.",
  mode: "pseudo",
  token: "USER",
  patterns: [
    EMAIL_IP_LITERAL,
    EMAIL,
    DOMAIN_USER,
    DOMAIN_USER_JSON,
    SID,
    LDAP_DN_SINGLE,
    LDAP_DN_CN,
    ARN_USER,
    ARN_ASSUMED_ROLE_SESSION,
    K8S_SERVICE_ACCOUNT,
    SSHD_FOR_USER,
    SSHD_RUSER,
    SSHD_LOGNAME,
    SUDO_USER,
    GENERIC_CTX
  ],
  aggressivePatterns: [SLACK_USER_ID_AGGRESSIVE],
  validate: validateUser,
  jsonKeys: [
    "email",
    "username",
    "user",
    "emailAddress",
    "mail",
    "userEmail",
    "user_name",
    "login",
    "account",
    "samAccountName",
    "userPrincipalName",
    "upn",
    "actor",
    "principal",
    "owner",
    "createdBy",
    "modifiedBy",
    "firstName",
    "lastName",
    "fullName",
    "displayName",
    "givenName",
    "surname",
    "userId",
    "uid",
    "usr",
    "usrName",
    "usrEmail",
    "usrId",
    "loginName",
    "loginId",
    "logonName",
    "userSid",
    "requestedBy",
    "submittedBy",
    "approvedBy",
    "updatedBy",
    "deletedBy",
    "author",
    "committer",
    "reporter",
    "assignee",
    "customerName",
    "customerEmail",
    "contactEmail",
    "contactName",
    "recipient",
    "recipients",
    "sender",
    "replyTo",
    "mailFrom",
    "rcptTo",
    "envelopeFrom",
    "envelopeTo",
    "emails",
    "primaryEmail",
    "workEmail",
    "personalEmail",
    "middleName",
    "nickname",
    "maidenName",
    "familyName",
    "legalName",
    "realName",
    "gecos",
    "distinguishedName",
    "userDn",
    "userDisplayName",
    "employeeId",
    "employeeNumber",
    "staffId",
    "studentId",
    "impersonatedUser",
    "effectiveUser",
    "sudoUser",
    "ruser",
    "suser",
    "duser"
  ],
  jsonKeyContains: [
    "owner",
    "username",
    "email",
    "principalname",
    "loginname",
    "firstname",
    "lastname",
    "fullname"
  ]
};

// src/rules/registry.ts
var builtinRules = [
  secretsRule,
  sessionCookiesRule,
  paymentInfoRule,
  govIdentifiersRule,
  healthInfoRule,
  phoneNumbersRule,
  ipAddressesRule,
  hostnamesRule,
  usersRule,
  geoLocationRule,
  homePathsRule
];
var builtinRuleIds = builtinRules.map(
  (rule) => rule.id
);
var builtinsById = new Map(builtinRules.map((rule) => [rule.id, rule]));
function getBuiltinRule(id) {
  return builtinsById.get(id);
}

// src/core/regexSource.ts
function matchParen(source, openIndex) {
  let depth = 0;
  let inClass = false;
  for (let index = openIndex; index < source.length; index += 1) {
    const char = source[index];
    if (char === "\\") {
      index += 1;
      continue;
    }
    if (inClass) {
      if (char === "]") {
        inClass = false;
      }
      continue;
    }
    if (char === "[") {
      inClass = true;
      continue;
    }
    if (char === "(") {
      depth += 1;
    } else if (char === ")") {
      depth -= 1;
      if (depth === 0) {
        return index;
      }
    }
  }
  return -1;
}
function countCapturingGroups(source) {
  let count = 0;
  let inClass = false;
  for (let index = 0; index < source.length; index += 1) {
    const char = source[index];
    if (char === "\\") {
      index += 1;
      continue;
    }
    if (inClass) {
      if (char === "]") {
        inClass = false;
      }
      continue;
    }
    if (char === "[") {
      inClass = true;
      continue;
    }
    if (char !== "(") {
      continue;
    }
    const next = source.slice(index, index + 4);
    if (next.startsWith("(?:") || next.startsWith("(?=") || next.startsWith("(?!") || next.startsWith("(?<=") || next.startsWith("(?<!")) {
      continue;
    }
    count += 1;
  }
  return count;
}
function deriveGateSource(source) {
  let output = "";
  let inClass = false;
  for (let index = 0; index < source.length; index += 1) {
    const char = source[index];
    if (char === "\\") {
      output += source.slice(index, index + 2);
      index += 1;
      continue;
    }
    if (inClass) {
      output += char;
      if (char === "]") {
        inClass = false;
      }
      continue;
    }
    if (char === "[") {
      inClass = true;
      output += char;
      continue;
    }
    if (char === "(" && source.startsWith("(?<=", index)) {
      const close = matchParen(source, index);
      if (close === -1) {
        output += char;
        continue;
      }
      output += `(?:${source.slice(index + 4, close)})`;
      index = close;
      continue;
    }
    if (char === "(" && (source.startsWith("(?<!", index) || source.startsWith("(?=", index) || source.startsWith("(?!", index))) {
      const close = matchParen(source, index);
      if (close === -1) {
        output += char;
        continue;
      }
      index = close;
      continue;
    }
    output += char;
  }
  return output;
}
function lineHasAnyChar(line, chars) {
  for (let index = 0; index < line.length; index += 1) {
    if (chars.includes(line[index])) {
      return true;
    }
  }
  return false;
}

// src/rules/validateRule.ts
var RULE_ID_PATTERN = /^[A-Za-z_$][A-Za-z0-9_$]*$/;
var TOKEN_PATTERN = /^[A-Z][A-Z0-9]*$/;
var NAMED_GROUP_PATTERN = /\(\?<[^=!]/;
function requireText(value, rule, field) {
  if (typeof value !== "string" || value.trim().length === 0) {
    throw new InvalidRuleError(`Rule "${rule}": \`${field}\` must be a non-empty string.`);
  }
  return value;
}
function assertPatterns(patterns, ruleId, field) {
  if (patterns === void 0) {
    return [];
  }
  if (!Array.isArray(patterns)) {
    throw new InvalidRuleError(`Rule "${ruleId}": \`${field}\` must be an array of strings.`);
  }
  return patterns.map((pattern, index) => {
    if (typeof pattern !== "string" || pattern.length === 0) {
      throw new InvalidRuleError(
        `Rule "${ruleId}": \`${field}[${index}]\` must be a non-empty regular expression source.`
      );
    }
    if (NAMED_GROUP_PATTERN.test(pattern)) {
      throw new InvalidRuleError(
        `Rule "${ruleId}": \`${field}[${index}]\` must not declare a named capture group.`
      );
    }
    try {
      new RegExp(pattern, "u");
    } catch (cause) {
      throw new InvalidRuleError(
        `Rule "${ruleId}": \`${field}[${index}]\` is not a valid Unicode regular expression: ${String(cause)}`
      );
    }
    if (countCapturingGroups(pattern) > 1) {
      throw new InvalidRuleError(
        `Rule "${ruleId}": \`${field}[${index}]\` must contain at most one capturing group, which marks the value to replace.`
      );
    }
    return pattern;
  });
}
function validateRule(rule) {
  if (typeof rule !== "object" || rule === null) {
    throw new InvalidRuleError("A rule must be an object.");
  }
  const id = requireText(rule.id, String(rule.id), "id");
  if (!RULE_ID_PATTERN.test(id)) {
    throw new InvalidRuleError(
      `Rule "${id}": \`id\` must be a valid ASCII identifier matching ${RULE_ID_PATTERN.source}.`
    );
  }
  requireText(rule.label, id, "label");
  requireText(rule.description, id, "description");
  if (rule.mode !== "pseudo" && rule.mode !== "mask") {
    throw new InvalidRuleError(`Rule "${id}": \`mode\` must be either "pseudo" or "mask".`);
  }
  if (rule.token !== void 0 && !TOKEN_PATTERN.test(rule.token)) {
    throw new InvalidRuleError(
      `Rule "${id}": \`token\` must match ${TOKEN_PATTERN.source}, so replacement tokens stay recognizable.`
    );
  }
  const patterns = assertPatterns(rule.patterns, id, "patterns");
  const aggressivePatterns = assertPatterns(rule.aggressivePatterns, id, "aggressivePatterns");
  if (patterns.length === 0 && aggressivePatterns.length === 0) {
    throw new InvalidRuleError(`Rule "${id}": at least one pattern is required.`);
  }
  if (rule.jsonKeys !== void 0) {
    if (!Array.isArray(rule.jsonKeys)) {
      throw new InvalidRuleError(`Rule "${id}": \`jsonKeys\` must be an array of strings.`);
    }
    for (const [index, key] of rule.jsonKeys.entries()) {
      requireText(key, id, `jsonKeys[${index}]`);
    }
  }
  if (rule.jsonKeyContains !== void 0) {
    if (!Array.isArray(rule.jsonKeyContains)) {
      throw new InvalidRuleError(`Rule "${id}": \`jsonKeyContains\` must be an array of strings.`);
    }
    for (const [index, fragment] of rule.jsonKeyContains.entries()) {
      requireText(fragment, id, `jsonKeyContains[${index}]`);
    }
  }
  if (rule.validate !== void 0 && typeof rule.validate !== "function") {
    throw new InvalidRuleError(`Rule "${id}": \`validate\` must be a function.`);
  }
  return rule;
}

// src/rules/defineRule.ts
function defineRule(rule) {
  return validateRule(rule);
}

exports.InvalidKeyError = InvalidKeyError;
exports.InvalidOptionError = InvalidOptionError;
exports.InvalidRuleError = InvalidRuleError;
exports.SanitizationAbortedError = SanitizationAbortedError;
exports.SanitizerError = SanitizerError;
exports.UnknownRuleError = UnknownRuleError;
exports.builtinRuleIds = builtinRuleIds;
exports.builtinRules = builtinRules;
exports.countCapturingGroups = countCapturingGroups;
exports.defineRule = defineRule;
exports.deriveGateSource = deriveGateSource;
exports.getBuiltinRule = getBuiltinRule;
exports.isSanitizerError = isSanitizerError;
exports.lineHasAnyChar = lineHasAnyChar;
exports.validateRule = validateRule;
//# sourceMappingURL=chunk-VELXTD3L.cjs.map
//# sourceMappingURL=chunk-VELXTD3L.cjs.map