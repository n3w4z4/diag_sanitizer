import { Readable, Writable } from 'node:stream';
import { S as SanitizerOptions, a as SanitizeProgress, A as AbortSignalLike, T as TextSource, b as SanitizeReport, c as TextSink } from './index-BYEGdnwh.cjs';
export { d as AlwaysRedactOptions, B as BlobLike, e as BuiltinRuleId, K as KeyEncoding, L as LineOptions, N as NeverRedactOptions, f as NeverRedactRuleEntry, R as ReadableStreamLike, g as RedactionMode, h as ReportOptions, i as RuleCounts, j as RuleId, k as RuleInfo, l as RuleSelector, m as SanitizeReplacement, n as SanitizeRule, o as SanitizeSegment, p as SanitizeStreamOptions, q as SanitizeTextResult, r as Sanitizer, s as builtinRuleIds, t as builtinRules, u as defineRule, v as getBuiltinRule } from './index-BYEGdnwh.cjs';
export { ByteRange, InvalidKeyError, InvalidOptionError, InvalidRuleError, MergeReportsOptions, PlanLineRangesOptions, SanitizationAbortedError, SanitizerError, SanitizerErrorCode, StringSink, UnknownRuleError, createSanitizer, fromBlob, fromString, fromWebStream, generateKey, isSanitizerError, mergeReports, planLineAlignedRanges, sanitizeStream, sanitizeText, toCallbackSink, toNullSink, toStringSink } from './index.cjs';

/**
 * Reads a Node readable stream as UTF-8 text.
 *
 * Byte chunks are decoded across chunk boundaries, so multi-byte characters are never split.
 */
declare function fromNodeStream(stream: Readable | AsyncIterable<string | Uint8Array>): TextSource;
/**
 * Reads a file as UTF-8 text.
 *
 * @param path Path to the file to read.
 * @param chunkBytes Read buffer size.
 */
declare function fromFile(path: string, chunkBytes?: number): TextSource;
/**
 * Writes sanitized text to a Node writable stream, respecting backpressure.
 *
 * The stream is not ended when the run finishes, so it is safe to pass `process.stdout`.
 */
declare function toNodeStream(stream: Writable): TextSink;
/**
 * Writes sanitized text to a file, creating or truncating it.
 *
 * The file is closed and flushed when the run finishes.
 */
declare function toFile(path: string): TextSink;
/** Options for {@link sanitizeFile}. */
interface SanitizeFileOptions extends SanitizerOptions {
    /** Path of the file to read. */
    input: string;
    /** Path to write the sanitized result to. Omit for a report-only run. */
    output?: string;
    /** Read buffer size, in bytes. */
    chunkBytes?: number;
    /** Called after each chunk with a live snapshot of progress. */
    onProgress?: (progress: SanitizeProgress) => void;
    /** Aborts the run between lines. A partially written output file is left in place. */
    signal?: AbortSignalLike;
}
/**
 * Sanitizes a file on disk, streaming it so memory use stays flat regardless of file size.
 *
 * @returns The report for the whole file.
 * @throws {SanitizationAbortedError} When `options.signal` is aborted.
 *
 * @example
 * ```ts
 * const report = await sanitizeFile({
 *   input: 'app.log',
 *   output: 'app.sanitized.log',
 *   rules: ['secrets', 'ips'],
 * });
 *
 * console.log(`${report.totalMatches} values redacted`);
 * ```
 */
declare function sanitizeFile(options: SanitizeFileOptions): Promise<SanitizeReport>;

export { AbortSignalLike, type SanitizeFileOptions, SanitizeProgress, SanitizeReport, SanitizerOptions, TextSink, TextSource, fromFile, fromNodeStream, sanitizeFile, toFile, toNodeStream };
