'use strict';

var chunkVELXTD3L_cjs = require('./chunk-VELXTD3L.cjs');

// src/core/constants.ts
var DEFAULT_PREVIEW_BYTES = 256 * 1024;
var DEFAULT_RANGE_PROBE_BYTES = 256 * 1024;
var DEFAULT_RANGE_MAX_PROBE_BYTES = 16 * 1024 * 1024;
var DEFAULT_MAX_LINE_CHARS = 1024 * 1024;
var DEFAULT_LINE_OVERLAP_CHARS = 1024;
var DEFAULT_KEY_BYTES = 32;
var MASK_TOKEN_PREFIX = "R";
var ALWAYS_REDACT_RULE_ID = "custom";
var ALWAYS_REDACT_TOKEN = "CUSTOM";

// src/core/hmac.ts
var BLOCK_BYTES = 64;
var DIGEST_BYTES = 32;
var K = new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var INITIAL_STATE = new Uint32Array([
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
]);
function rotr(value, bits) {
  return (value >>> bits | value << 32 - bits) >>> 0;
}
function concatBytes(a, b) {
  const out = new Uint8Array(a.length + b.length);
  out.set(a, 0);
  out.set(b, a.length);
  return out;
}
function padMessage(message) {
  const bitLength = message.length * 8;
  const paddedLength = Math.ceil((message.length + 9) / BLOCK_BYTES) * BLOCK_BYTES;
  const padded = new Uint8Array(paddedLength);
  padded.set(message);
  padded[message.length] = 128;
  const view = new DataView(padded.buffer);
  view.setUint32(paddedLength - 8, Math.floor(bitLength / 2 ** 32), false);
  view.setUint32(paddedLength - 4, bitLength >>> 0, false);
  return padded;
}
function sha256(message) {
  const padded = padMessage(message);
  const view = new DataView(padded.buffer);
  const state = Uint32Array.from(INITIAL_STATE);
  const w = new Uint32Array(64);
  for (let offset = 0; offset < padded.length; offset += BLOCK_BYTES) {
    for (let i = 0; i < 16; i += 1) {
      w[i] = view.getUint32(offset + i * 4, false);
    }
    for (let i = 16; i < 64; i += 1) {
      const s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ w[i - 15] >>> 3;
      const s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ w[i - 2] >>> 10;
      w[i] = w[i - 16] + s0 + w[i - 7] + s1 >>> 0;
    }
    let a = state[0];
    let b = state[1];
    let c = state[2];
    let d = state[3];
    let e = state[4];
    let f = state[5];
    let g = state[6];
    let h = state[7];
    for (let i = 0; i < 64; i += 1) {
      const s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
      const ch = e & f ^ ~e & g;
      const temp1 = h + s1 + ch + K[i] + w[i] >>> 0;
      const s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
      const maj = a & b ^ a & c ^ b & c;
      const temp2 = s0 + maj >>> 0;
      h = g;
      g = f;
      f = e;
      e = d + temp1 >>> 0;
      d = c;
      c = b;
      b = a;
      a = temp1 + temp2 >>> 0;
    }
    state[0] = state[0] + a >>> 0;
    state[1] = state[1] + b >>> 0;
    state[2] = state[2] + c >>> 0;
    state[3] = state[3] + d >>> 0;
    state[4] = state[4] + e >>> 0;
    state[5] = state[5] + f >>> 0;
    state[6] = state[6] + g >>> 0;
    state[7] = state[7] + h >>> 0;
  }
  const digest = new Uint8Array(DIGEST_BYTES);
  const digestView = new DataView(digest.buffer);
  for (let i = 0; i < 8; i += 1) {
    digestView.setUint32(i * 4, state[i], false);
  }
  return digest;
}
function normalizeKey(key) {
  const hashed = key.length > BLOCK_BYTES ? sha256(key) : key;
  if (hashed.length === BLOCK_BYTES) {
    return hashed;
  }
  const padded = new Uint8Array(BLOCK_BYTES);
  padded.set(hashed);
  return padded;
}
function createHmacSha256(key) {
  const block = normalizeKey(key);
  const ipad = new Uint8Array(BLOCK_BYTES);
  const opad = new Uint8Array(BLOCK_BYTES);
  for (let i = 0; i < BLOCK_BYTES; i += 1) {
    ipad[i] = block[i] ^ 54;
    opad[i] = block[i] ^ 92;
  }
  return (message) => sha256(concatBytes(opad, sha256(concatBytes(ipad, message))));
}
function hexToBytes(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i += 1) {
    bytes[i] = Number.parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  }
  return bytes;
}
function bytesToHex(bytes) {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

// src/core/key.ts
var HEX_PATTERN = /^(?:[0-9a-fA-F]{2})+$/;
function generateKey(byteLength = DEFAULT_KEY_BYTES) {
  if (!Number.isInteger(byteLength) || byteLength < 16) {
    throw new chunkVELXTD3L_cjs.InvalidKeyError(`Key length must be an integer of at least 16 bytes, got ${byteLength}.`);
  }
  const source = globalThis.crypto;
  if (typeof source?.getRandomValues !== "function") {
    throw new chunkVELXTD3L_cjs.InvalidKeyError(
      "No secure random source available. Pass an explicit `key` or provide a Web Crypto implementation on globalThis.crypto."
    );
  }
  const bytes = new Uint8Array(byteLength);
  source.getRandomValues(bytes);
  return bytesToHex(bytes);
}
function assertKey(key, encoding) {
  if (key.length === 0) {
    throw new chunkVELXTD3L_cjs.InvalidKeyError("Key must not be empty.");
  }
  if (encoding === "hex" && !HEX_PATTERN.test(key)) {
    throw new chunkVELXTD3L_cjs.InvalidKeyError(
      'A hex key must contain an even number of hexadecimal characters. Pass `keyEncoding: "utf8"` for a passphrase.'
    );
  }
}

// src/rules/alwaysRedact.ts
function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function normalizeValues(values) {
  const unique = new Set(values.map((value) => value.trim()).filter((value) => value.length > 0));
  return [...unique].sort((left, right) => right.length - left.length || left.localeCompare(right));
}
function normalizePatterns(patterns) {
  return patterns.map((pattern) => {
    const source = typeof pattern === "string" ? pattern : pattern.source;
    try {
      new RegExp(source, "u");
    } catch (cause) {
      throw new chunkVELXTD3L_cjs.InvalidOptionError(
        `alwaysRedact.patterns contains an invalid regular expression: ${String(cause)}`
      );
    }
    return `(?:${source})`;
  });
}
function createAlwaysRedactRule(options) {
  if (!options) {
    return null;
  }
  const patterns = [
    ...normalizeValues(options.values ?? []).map((value) => `(?:${escapeRegExp(value)})`),
    ...normalizePatterns(options.patterns ?? [])
  ];
  if (patterns.length === 0) {
    return null;
  }
  return {
    id: options.ruleId ?? ALWAYS_REDACT_RULE_ID,
    label: "Always redacted",
    description: "Values and patterns the caller marked as always sensitive.",
    mode: options.mode ?? "pseudo",
    token: options.token ?? ALWAYS_REDACT_TOKEN,
    patterns
  };
}

// src/core/allowlist.ts
function patternSource(pattern) {
  return typeof pattern === "string" ? pattern : pattern.source;
}
function compileAnchored(patterns) {
  const sources = patterns.map(patternSource).filter((source) => source.length > 0);
  if (sources.length === 0) {
    return null;
  }
  const combined = sources.map((source) => `(?:${source})`).join("|");
  try {
    return new RegExp(`^(?:${combined})$`, "u");
  } catch (cause) {
    throw new chunkVELXTD3L_cjs.InvalidOptionError(
      `neverRedact.patterns contains an invalid regular expression: ${String(cause)}`
    );
  }
}
function createAllowList(options) {
  const values = new Set((options?.values ?? []).filter((value) => value.length > 0));
  const pattern = compileAnchored(options?.patterns ?? []);
  const byRule = /* @__PURE__ */ new Map();
  for (const entry of options?.byRule ?? []) {
    const existing = byRule.get(entry.ruleId) ?? /* @__PURE__ */ new Set();
    for (const value of entry.values) {
      if (value.length > 0) {
        existing.add(value);
      }
    }
    byRule.set(entry.ruleId, existing);
  }
  return {
    empty: values.size === 0 && pattern === null && byRule.size === 0,
    values,
    pattern,
    byRule
  };
}
function isAllowed(allow, ruleId, value) {
  if (allow.empty) {
    return false;
  }
  if (allow.values.has(value)) {
    return true;
  }
  if (allow.byRule.get(ruleId)?.has(value) === true) {
    return true;
  }
  return allow.pattern !== null && allow.pattern.test(value);
}

// src/core/pseudonymize.ts
var TOKEN_HEX_LENGTH = 16;
var TOKEN_BYTES = TOKEN_HEX_LENGTH / 2;
var textEncoder = new TextEncoder();
function createPseudonymizer(key, encoding) {
  const keyBytes = encoding === "utf8" ? textEncoder.encode(key) : hexToBytes(key);
  const sign = createHmacSha256(keyBytes);
  const cache = /* @__PURE__ */ new Map();
  return (ruleId, value) => {
    const cacheKey = `${ruleId}\0${value}`;
    const cached = cache.get(cacheKey);
    if (cached !== void 0) {
      return cached;
    }
    const digest = sign(textEncoder.encode(cacheKey));
    const token = bytesToHex(digest.subarray(0, TOKEN_BYTES));
    cache.set(cacheKey, token);
    return token;
  };
}
function replacementPrefix(rule) {
  if (rule.mode === "mask") {
    return MASK_TOKEN_PREFIX;
  }
  return rule.token ?? rule.id.toUpperCase();
}

// src/core/compile.ts
var SKIP_REGEX_GATE = /* @__PURE__ */ new Set(["ips", "hosts"]);
function gateCharsFor(ruleId, aggressive) {
  if (ruleId === "phoneNumbers") {
    return "0123456789";
  }
  if (ruleId === "paymentInfo" && !aggressive) {
    return "0123456789";
  }
  return null;
}
function compileOne(rule, aggressive) {
  const patterns = aggressive ? [...rule.patterns, ...rule.aggressivePatterns ?? []] : rule.patterns;
  if (patterns.length === 0) {
    return null;
  }
  const source = patterns.join("|");
  const fragments = [];
  for (const pattern of patterns) {
    try {
      fragments.push({
        regex: new RegExp(pattern, "gu"),
        hasValueGroup: chunkVELXTD3L_cjs.countCapturingGroups(pattern) === 1
      });
    } catch (cause) {
      throw new chunkVELXTD3L_cjs.InvalidRuleError(`Failed to compile rule "${rule.id}": ${String(cause)}`);
    }
  }
  const gateSource = patterns.map(chunkVELXTD3L_cjs.deriveGateSource).join("|");
  let gate = null;
  if (!SKIP_REGEX_GATE.has(rule.id) && gateSource.length > 0 && gateSource !== source) {
    try {
      gate = new RegExp(gateSource, "gu");
    } catch {
      gate = null;
    }
  }
  return {
    id: rule.id,
    fragments,
    gate,
    gateChars: gateCharsFor(rule.id, aggressive)
  };
}
function compileRules(rules, aggressive) {
  const compiled = [];
  for (const rule of rules) {
    const one = compileOne(rule, aggressive);
    if (one) {
      compiled.push(one);
    }
  }
  return compiled;
}
function createRuleContext(input) {
  const { rules } = input;
  return {
    compiled: compileRules(rules, input.aggressive),
    rules,
    ruleIds: rules.map((rule) => rule.id),
    rulesById: new Map(rules.map((rule) => [rule.id, rule])),
    prefixById: new Map(rules.map((rule) => [rule.id, replacementPrefix(rule)])),
    pseudonymize: input.pseudonymize,
    allow: input.allow,
    contextChars: input.contextChars,
    json: input.json
  };
}
function buildReplacement(ctx, ruleId, value) {
  return `<${ctx.prefixById.get(ruleId) ?? ruleId.toUpperCase()}:${ctx.pseudonymize(ruleId, value)}>`;
}

// src/core/lineSplitter.ts
function extractLines(buffer) {
  const lines = [];
  let start = 0;
  for (let i = 0; i < buffer.length; i += 1) {
    if (buffer[i] === "\n") {
      lines.push(buffer.slice(start, i + 1));
      start = i + 1;
    }
  }
  return { lines, rest: buffer.slice(start) };
}
function createLineSplitter(options = {}) {
  const maxLineChars = options.maxLineChars ?? DEFAULT_MAX_LINE_CHARS;
  const overlapChars = options.overlapChars ?? DEFAULT_LINE_OVERLAP_CHARS;
  if (maxLineChars < 1) {
    throw new chunkVELXTD3L_cjs.InvalidOptionError("lines.maxLineChars must be at least 1.");
  }
  if (overlapChars < 0 || overlapChars >= maxLineChars) {
    throw new chunkVELXTD3L_cjs.InvalidOptionError(
      `lines.overlapChars must be between 0 and lines.maxLineChars - 1 (${maxLineChars - 1}), got ${overlapChars}.`
    );
  }
  let carry = "";
  function push(chunk) {
    carry += chunk;
    const { lines, rest } = extractLines(carry);
    carry = rest;
    while (carry.length > maxLineChars) {
      const cut = carry.length - overlapChars;
      lines.push(carry.slice(0, cut));
      carry = carry.slice(cut);
    }
    return lines;
  }
  function flush() {
    if (carry.length === 0) {
      return [];
    }
    const rest = carry;
    carry = "";
    return [rest];
  }
  return { push, flush };
}

// src/core/jsonKeyMatcher.ts
var RESOLVE_CACHE_LIMIT = 1e4;
function normalizeKey2(key) {
  return key.toLowerCase().replace(/[-_.\s]/g, "");
}
function shouldPreserveJsonValue(value) {
  return value.length === 0 || value === "-";
}
function buildTables(rules) {
  const exact = /* @__PURE__ */ new Map();
  const contains = [];
  for (const rule of rules) {
    for (const key of rule.jsonKeys ?? []) {
      const normalized = normalizeKey2(key);
      if (!exact.has(normalized)) {
        exact.set(normalized, rule);
      }
    }
    for (const fragment of rule.jsonKeyContains ?? []) {
      contains.push({ fragment: normalizeKey2(fragment), rule });
    }
  }
  return { exact, contains };
}
function lastSegment(key) {
  const dot = key.lastIndexOf(".");
  return dot === -1 ? key : key.slice(dot + 1);
}
function resolveUncached(tables, key, parent) {
  const dot = key.lastIndexOf(".");
  const leaf = normalizeKey2(dot === -1 ? key : key.slice(dot + 1));
  const parentRaw = dot === -1 ? parent : key.slice(0, dot);
  if (leaf.length === 0) {
    return null;
  }
  if (parentRaw !== void 0) {
    const scoped = tables.exact.get(normalizeKey2(lastSegment(parentRaw)) + leaf);
    if (scoped) {
      return scoped;
    }
  }
  const exact = tables.exact.get(leaf);
  if (exact) {
    return exact;
  }
  for (const entry of tables.contains) {
    if (leaf.includes(entry.fragment)) {
      return entry.rule;
    }
  }
  return null;
}
function buildMatcher(rules) {
  const tables = buildTables(rules);
  const cache = /* @__PURE__ */ new Map();
  return {
    resolve(key, parent) {
      const cacheKey = parent === void 0 ? key : `${parent}\0${key}`;
      let rule = cache.get(cacheKey);
      if (rule === void 0) {
        rule = resolveUncached(tables, key, parent);
        if (cache.size >= RESOLVE_CACHE_LIMIT) {
          cache.clear();
        }
        cache.set(cacheKey, rule);
      }
      return rule ?? void 0;
    }
  };
}
var matcherCache = /* @__PURE__ */ new WeakMap();
function jsonKeyMatcher(rules) {
  const cached = matcherCache.get(rules);
  if (cached) {
    return cached;
  }
  const matcher = buildMatcher(rules);
  matcherCache.set(rules, matcher);
  return matcher;
}

// src/core/redactKeyValuePairs.ts
var NUMBER = "(-?\\d+(?:\\.\\d+)?(?:[eE][+-]?\\d+)?)(?![\\w.:+-])";
var DOUBLE_QUOTED = new RegExp(
  `(?<![\\\\\\w])"((?:[^"\\\\\\r\\n]|\\\\.){1,128})"\\s*:\\s*(?:"((?:[^"\\\\]|\\\\.)*)"|${NUMBER})`,
  "g"
);
var ESCAPED = new RegExp(
  `\\\\"((?:[^"\\\\\\r\\n]|\\\\\\\\){1,128})\\\\"\\s*:\\s*(?:\\\\"((?:\\\\\\\\\\\\"|\\\\\\\\|\\\\[^"\\\\]|[^"\\\\])*)\\\\"|${NUMBER})`,
  "g"
);
var SINGLE_QUOTED = new RegExp(
  `(?<![\\\\\\w])'((?:[^'\\\\\\r\\n]|\\\\.){1,128})'\\s*:\\s*(?:'((?:[^'\\\\]|\\\\.)*)'|"((?:[^"\\\\]|\\\\.)*)"|${NUMBER})`,
  "g"
);
function decodeJsonString(raw) {
  if (!raw.includes("\\")) {
    return raw;
  }
  try {
    return JSON.parse(`"${raw}"`);
  } catch {
    return raw;
  }
}
function decodeEscapedJsonString(raw) {
  return decodeJsonString(decodeJsonString(raw));
}
function decodePythonString(raw) {
  return raw.includes("\\") ? raw.replace(/\\(['"\\])/g, "$1") : raw;
}
function collect(line, regex, rules, decode, numberQuote, out) {
  const matcher = jsonKeyMatcher(rules);
  regex.lastIndex = 0;
  for (let found = regex.exec(line); found !== null; found = regex.exec(line)) {
    const rawKey = found[1];
    let rawValue;
    let quote = "";
    for (let group = 2; group < found.length; group += 1) {
      if (found[group] !== void 0) {
        rawValue = found[group];
        quote = group === found.length - 1 ? numberQuote : "";
        break;
      }
    }
    if (rawValue === void 0) {
      continue;
    }
    const value = quote === "" ? decode(rawValue) : rawValue;
    if (shouldPreserveJsonValue(value)) {
      continue;
    }
    const rule = matcher.resolve(decode(rawKey));
    if (!rule) {
      continue;
    }
    const end = found.index + found[0].length - (quote === "" ? 1 : 0);
    const valueEnd = quote === "" && regex === ESCAPED ? end - 1 : end;
    out.push({
      keyStart: found.index,
      match: { start: valueEnd - rawValue.length, end: valueEnd, value, rule, quote }
    });
  }
}
function findKeyValueMatches(line, rules) {
  const doubleQuoted = line.includes('":') || line.includes('" :');
  const singleQuoted = line.includes("':") || line.includes("' :");
  if (!doubleQuoted && !singleQuoted) {
    return [];
  }
  const candidates = [];
  if (doubleQuoted) {
    collect(line, DOUBLE_QUOTED, rules, decodeJsonString, '"', candidates);
    if (line.includes('\\"')) {
      collect(line, ESCAPED, rules, decodeEscapedJsonString, '\\"', candidates);
    }
  }
  if (singleQuoted) {
    collect(line, SINGLE_QUOTED, rules, decodePythonString, "'", candidates);
  }
  if (candidates.length === 0) {
    return [];
  }
  candidates.sort((left, right) => left.keyStart - right.keyStart);
  const matches = [];
  let floor = 0;
  for (const { keyStart, match } of candidates) {
    if (keyStart >= floor) {
      matches.push(match);
      floor = match.end;
    }
  }
  return matches;
}

// src/core/redactLine.ts
function sliceContext(text, index, length, chars) {
  return {
    contextBefore: text.slice(Math.max(0, index - chars), index),
    contextAfter: text.slice(index + length, index + length + chars)
  };
}
function advance(cursor, line, minStart) {
  const { regex } = cursor;
  for (; ; ) {
    if (regex.lastIndex > minStart) {
      regex.lastIndex = minStart;
    }
    const match = regex.exec(line);
    if (match === null) {
      cursor.active = false;
      return;
    }
    const original = (cursor.hasValueGroup ? match[1] : void 0) ?? match[0];
    const start = match.index + match[0].length - original.length;
    if (match[0].length === 0) {
      regex.lastIndex += 1;
    } else if (start > match.index) {
      regex.lastIndex = start;
    }
    if (start >= minStart) {
      cursor.active = true;
      cursor.start = start;
      cursor.original = original;
      return;
    }
  }
}
function openCursors(line, compiled) {
  const cursors = [];
  for (let ruleIndex = 0; ruleIndex < compiled.length; ruleIndex += 1) {
    const rule = compiled[ruleIndex];
    if (rule.gateChars !== null && !chunkVELXTD3L_cjs.lineHasAnyChar(line, rule.gateChars)) {
      continue;
    }
    if (rule.gate !== null) {
      rule.gate.lastIndex = 0;
      if (!rule.gate.test(line)) {
        continue;
      }
    }
    for (let fragmentIndex = 0; fragmentIndex < rule.fragments.length; fragmentIndex += 1) {
      const fragment = rule.fragments[fragmentIndex];
      fragment.regex.lastIndex = 0;
      const cursor = {
        ruleIndex,
        fragmentIndex,
        ruleId: rule.id,
        regex: fragment.regex,
        hasValueGroup: fragment.hasValueGroup,
        active: false,
        start: 0,
        original: ""
      };
      advance(cursor, line, 0);
      if (cursor.active) {
        cursors.push(cursor);
      }
    }
  }
  return cursors;
}
function pickNext(cursors) {
  let best = null;
  for (const cursor of cursors) {
    if (!cursor.active) {
      continue;
    }
    if (best === null || cursor.start < best.start || cursor.start === best.start && (cursor.ruleIndex < best.ruleIndex || cursor.ruleIndex === best.ruleIndex && cursor.fragmentIndex < best.fragmentIndex)) {
      best = cursor;
    }
  }
  return best;
}
function blankOut(line, spans) {
  let out = "";
  let cursor = 0;
  for (const span of spans) {
    out += line.slice(cursor, span.start) + " ".repeat(span.end - span.start);
    cursor = span.end;
  }
  return out + line.slice(cursor);
}
function redactLine(line, ctx, options = {}) {
  const { compiled, rulesById, allow, contextChars } = ctx;
  const withSegments = options.withSegments ?? false;
  const withMatches = options.withMatches ?? false;
  const keyed = ctx.json ? findKeyValueMatches(line, ctx.rules) : [];
  if (compiled.length === 0 && keyed.length === 0) {
    return {
      output: line,
      counts: {},
      matches: [],
      segments: withSegments ? { before: [{ text: line, changed: false }], after: [{ text: line, changed: false }] } : void 0
    };
  }
  const scan = keyed.length === 0 ? line : blankOut(line, keyed);
  const cursors = openCursors(scan, compiled);
  const counts = {};
  const matches = [];
  const before = [];
  const after = [];
  let output = "";
  let cursor = 0;
  let keyedIndex = 0;
  for (; ; ) {
    const next = pickNext(cursors);
    const pending = keyed[keyedIndex];
    if (pending !== void 0 && (next === null || pending.start <= next.start)) {
      keyedIndex += 1;
      if (!isAllowed(allow, pending.rule.id, pending.value)) {
        const token = buildReplacement(ctx, pending.rule.id, pending.value);
        const raw = line.slice(pending.start, pending.end);
        if (withSegments) {
          if (pending.start > cursor) {
            const gap = line.slice(cursor, pending.start);
            before.push({ text: gap, changed: false });
            after.push({ text: gap, changed: false });
          }
          before.push({ text: raw, changed: true });
          if (pending.quote) {
            after.push({ text: pending.quote, changed: false });
          }
          after.push({ text: token, changed: true });
          if (pending.quote) {
            after.push({ text: pending.quote, changed: false });
          }
        }
        output += line.slice(cursor, pending.start) + pending.quote + token + pending.quote;
        cursor = pending.end;
        counts[pending.rule.id] = (counts[pending.rule.id] ?? 0) + 1;
        if (withMatches) {
          matches.push({
            ruleId: pending.rule.id,
            original: pending.value,
            replacement: token,
            index: pending.start,
            ...contextChars > 0 ? sliceContext(line, pending.start, raw.length, contextChars) : {}
          });
        }
      }
      for (const candidate of cursors) {
        if (candidate.active && candidate.start < pending.end) {
          advance(candidate, scan, pending.end);
        }
      }
      continue;
    }
    if (next === null) {
      break;
    }
    if (pending !== void 0 && next.start + next.original.length > pending.start) {
      advance(next, scan, next.start + 1);
      continue;
    }
    const { start, original, ruleId } = next;
    const spanEnd = start + Math.max(original.length, 1);
    const rule = rulesById.get(ruleId);
    const accepted = rule !== void 0 && !(rule.validate !== void 0 && !rule.validate(original)) && !isAllowed(allow, rule.id, original);
    if (accepted) {
      const replacement = buildReplacement(ctx, rule.id, original);
      if (withSegments) {
        if (start > cursor) {
          const gap = line.slice(cursor, start);
          before.push({ text: gap, changed: false });
          after.push({ text: gap, changed: false });
        }
        before.push({ text: original, changed: true });
        after.push({ text: replacement, changed: true });
      }
      output += line.slice(cursor, start) + replacement;
      cursor = start + original.length;
      counts[rule.id] = (counts[rule.id] ?? 0) + 1;
      if (withMatches) {
        matches.push({
          ruleId: rule.id,
          original,
          replacement,
          index: start,
          ...contextChars > 0 ? sliceContext(line, start, original.length, contextChars) : {}
        });
      }
    }
    for (const candidate of cursors) {
      if (candidate.active && candidate.start < spanEnd) {
        advance(candidate, scan, spanEnd);
      }
    }
  }
  output += line.slice(cursor);
  if (withSegments && cursor < line.length) {
    const tail = line.slice(cursor);
    before.push({ text: tail, changed: false });
    after.push({ text: tail, changed: false });
  }
  return {
    output,
    counts,
    matches,
    segments: withSegments ? { before, after } : void 0
  };
}

// src/core/redactJsonLine.ts
var REPLACEMENT_TOKEN_RE = /<[A-Z][A-Z0-9]*:[0-9a-f]+>/g;
function looksLikeJson(line) {
  const trimmed = line.trim();
  return trimmed.length > 0 && (trimmed.startsWith("{") || trimmed.startsWith("["));
}
function mergeCounts(target, source) {
  for (const [id, count] of Object.entries(source)) {
    target[id] = (target[id] ?? 0) + count;
  }
}
function highlightReplacements(text) {
  const segments = [];
  let cursor = 0;
  REPLACEMENT_TOKEN_RE.lastIndex = 0;
  let match = REPLACEMENT_TOKEN_RE.exec(text);
  while (match !== null) {
    if (match.index > cursor) {
      segments.push({ text: text.slice(cursor, match.index), changed: false });
    }
    segments.push({ text: match[0], changed: true });
    cursor = match.index + match[0].length;
    match = REPLACEMENT_TOKEN_RE.exec(text);
  }
  if (cursor < text.length) {
    segments.push({ text: text.slice(cursor), changed: false });
  }
  return segments.length > 0 ? segments : [{ text, changed: false }];
}
function jsonStringContent(value) {
  return JSON.stringify(value).slice(1, -1);
}
function locateJsonNumber(text, value, from = 0) {
  const re = new RegExp(`:\\s*(${escapeRegExp(value)})(?![\\d.eE])`, "g");
  re.lastIndex = from;
  const match = re.exec(text);
  if (match === null) {
    return null;
  }
  return { index: match.index + match[0].length - value.length, length: value.length };
}
function locateQuotedJsonValue(text, value, from = 0) {
  const encoded = jsonStringContent(value);
  const quotedAt = text.indexOf(`"${encoded}"`, from);
  if (quotedAt === -1) {
    return null;
  }
  return { index: quotedAt + 1, length: encoded.length };
}
function findOriginal(text, original, from) {
  if (original.number === true) {
    return locateJsonNumber(text, original.value, from);
  }
  const encoded = jsonStringContent(original.value);
  if (original.wholeValue) {
    const quoted = `"${encoded}"`;
    const quotedIndex = text.indexOf(quoted, from);
    if (quotedIndex !== -1) {
      return { index: quotedIndex + 1, length: encoded.length };
    }
  }
  const needles = encoded === original.value ? [encoded] : [encoded, original.value];
  for (const needle of needles) {
    const index = text.indexOf(needle, from);
    if (index !== -1) {
      return { index, length: needle.length };
    }
  }
  return null;
}
function highlightOriginals(text, originals) {
  if (originals.length === 0) {
    return [{ text, changed: false }];
  }
  const segments = [];
  let cursor = 0;
  for (const original of originals) {
    if (original.value.length === 0) {
      continue;
    }
    const found = findOriginal(text, original, cursor);
    if (found === null) {
      continue;
    }
    if (found.index > cursor) {
      segments.push({ text: text.slice(cursor, found.index), changed: false });
    }
    segments.push({
      text: text.slice(found.index, found.index + found.length),
      changed: true
    });
    cursor = found.index + found.length;
  }
  if (cursor < text.length) {
    segments.push({ text: text.slice(cursor), changed: false });
  }
  return segments.length > 0 ? segments : [{ text, changed: false }];
}
function redactJsonLine(line, ctx, options = {}) {
  const terminatorMatch = /(\r\n|\r|\n)$/.exec(line);
  const terminator = terminatorMatch ? terminatorMatch[0] : "";
  const content = terminator ? line.slice(0, -terminator.length) : line;
  let parsed;
  try {
    parsed = JSON.parse(content);
  } catch {
    return null;
  }
  if (typeof parsed !== "object" || parsed === null) {
    return null;
  }
  const withSegments = options.withSegments ?? false;
  const withMatches = options.withMatches ?? false;
  const collectOriginals = withMatches || withSegments;
  const keyMatcher = jsonKeyMatcher(ctx.rules);
  const counts = {};
  const matches = [];
  const originals = [];
  const contextFor = (value) => {
    if (ctx.contextChars <= 0) {
      return {};
    }
    const encoded = jsonStringContent(value);
    const encodedIndex = content.indexOf(encoded);
    if (encodedIndex >= 0) {
      return sliceContext(content, encodedIndex, encoded.length, ctx.contextChars);
    }
    if (encoded !== value) {
      const rawIndex = content.indexOf(value);
      if (rawIndex >= 0) {
        return sliceContext(content, rawIndex, value.length, ctx.contextChars);
      }
    }
    return { contextBefore: "", contextAfter: "" };
  };
  const redactField = (rule, value, number) => {
    if (isAllowed(ctx.allow, rule.id, value)) {
      return null;
    }
    const replacement = buildReplacement(ctx, rule.id, value);
    counts[rule.id] = (counts[rule.id] ?? 0) + 1;
    if (withSegments) {
      originals.push({ value, wholeValue: true, number });
    }
    if (withMatches) {
      const located = number ? locateJsonNumber(content, value) : locateQuotedJsonValue(content, value);
      matches.push({
        ruleId: rule.id,
        original: value,
        replacement,
        index: located?.index ?? 0,
        ...located && ctx.contextChars > 0 ? sliceContext(content, located.index, located.length, ctx.contextChars) : ctx.contextChars > 0 ? { contextBefore: "", contextAfter: "" } : {}
      });
    }
    return replacement;
  };
  const redactValue = (value, key, parent) => {
    if (typeof value === "number") {
      const fieldRule = key === void 0 || !Number.isFinite(value) ? void 0 : keyMatcher.resolve(key, parent);
      return fieldRule ? redactField(fieldRule, String(value), true) ?? value : value;
    }
    if (typeof value === "string") {
      if (key !== void 0 && shouldPreserveJsonValue(value)) {
        return value;
      }
      const fieldRule = key === void 0 ? void 0 : keyMatcher.resolve(key, parent);
      if (fieldRule) {
        return redactField(fieldRule, value, false) ?? value;
      }
      const result = redactLine(value, ctx, { withMatches: collectOriginals });
      mergeCounts(counts, result.counts);
      if (collectOriginals) {
        for (const match of result.matches) {
          if (withSegments) {
            originals.push({ value: match.original, wholeValue: false });
          }
          if (withMatches) {
            matches.push({ ...match, ...contextFor(match.original) });
          }
        }
      }
      return result.output;
    }
    if (Array.isArray(value)) {
      return value.map((item) => redactValue(item, key, parent));
    }
    if (value !== null && typeof value === "object") {
      const out = {};
      for (const [entryKey, entryValue] of Object.entries(value)) {
        out[entryKey] = redactValue(entryValue, entryKey, key);
      }
      return out;
    }
    return value;
  };
  const output = JSON.stringify(redactValue(parsed)) + terminator;
  if (!withSegments) {
    return { output, counts, matches };
  }
  return {
    output,
    counts,
    matches,
    segments: {
      before: highlightOriginals(line, originals),
      after: highlightReplacements(output)
    }
  };
}

// src/core/report.ts
function createReportCollector(options = {}) {
  const previewBytes = options.previewBytes ?? DEFAULT_PREVIEW_BYTES;
  const collectReplacements = options.replacements ?? true;
  const maxPerRule = options.maxReplacementsPerRule;
  const limited = maxPerRule !== void 0;
  if (previewBytes < 0) {
    throw new chunkVELXTD3L_cjs.InvalidOptionError("report.previewBytes must not be negative.");
  }
  if (limited && (maxPerRule < 0 || !Number.isInteger(maxPerRule))) {
    throw new chunkVELXTD3L_cjs.InvalidOptionError("report.maxReplacementsPerRule must be a non-negative integer.");
  }
  const counts = {};
  const replacements = /* @__PURE__ */ new Map();
  const perRuleDistinct = limited ? /* @__PURE__ */ new Map() : null;
  const before = [];
  const after = [];
  let lineCount = 0;
  let previewBytesUsed = 0;
  let previewClosed = previewBytes === 0;
  let truncated = false;
  function needsSegments() {
    return !previewClosed;
  }
  function needsMatches() {
    return collectReplacements;
  }
  function record(result) {
    lineCount += 1;
    for (const [id, count] of Object.entries(result.counts)) {
      counts[id] = (counts[id] ?? 0) + count;
    }
    if (collectReplacements) {
      for (const match of result.matches) {
        const key = `${match.ruleId}\0${match.original}`;
        const existing = replacements.get(key);
        if (existing) {
          existing.count += 1;
          continue;
        }
        if (perRuleDistinct) {
          const n = perRuleDistinct.get(match.ruleId) ?? 0;
          if (n >= maxPerRule) {
            truncated = true;
            continue;
          }
          perRuleDistinct.set(match.ruleId, n + 1);
        }
        replacements.set(key, {
          ruleId: match.ruleId,
          original: match.original,
          replacement: match.replacement,
          count: 1,
          ...match.contextBefore !== void 0 ? { contextBefore: match.contextBefore, contextAfter: match.contextAfter } : {}
        });
      }
    }
    if (previewClosed) {
      return;
    }
    if (result.segments) {
      before.push(...result.segments.before);
      after.push(...result.segments.after);
    }
    previewBytesUsed += result.output.length;
    if (previewBytesUsed >= previewBytes) {
      previewClosed = true;
    }
  }
  function build(snapshot) {
    const includeReplacements = snapshot?.includeReplacements ?? true;
    let totalMatches = 0;
    for (const count of Object.values(counts)) {
      totalMatches += count;
    }
    return {
      counts: { ...counts },
      totalMatches,
      lineCount,
      replacements: includeReplacements ? [...replacements.values()] : [],
      preview: { before: [...before], after: [...after] },
      ...truncated && includeReplacements ? { replacementsTruncated: true } : {}
    };
  }
  return { needsSegments, needsMatches, record, build };
}

// src/core/resolveRules.ts
function toRule(selector) {
  if (typeof selector === "string") {
    const builtin = chunkVELXTD3L_cjs.getBuiltinRule(selector);
    if (!builtin) {
      throw new chunkVELXTD3L_cjs.UnknownRuleError(
        `Unknown rule "${selector}". Pass a rule object for custom rules, or one of the built-in identifiers.`
      );
    }
    return builtin;
  }
  return chunkVELXTD3L_cjs.validateRule(selector);
}
function resolveRules(selectors, extraRules = []) {
  const resolved = [];
  const positions = /* @__PURE__ */ new Map();
  for (const selector of [...selectors, ...extraRules]) {
    const rule = toRule(selector);
    const existing = positions.get(rule.id);
    if (existing === void 0) {
      positions.set(rule.id, resolved.length);
      resolved.push(rule);
    } else {
      resolved[existing] = rule;
    }
  }
  return resolved;
}

// src/core/sanitizer.ts
async function* toAsyncIterable(source) {
  yield* source;
}
function processLine(line, ctx, collector) {
  const options = {
    withSegments: collector.needsSegments(),
    withMatches: collector.needsMatches()
  };
  const parsed = ctx.json && looksLikeJson(line) ? redactJsonLine(line, ctx, options) : null;
  const result = parsed ?? redactLine(line, ctx, options);
  collector.record(result);
  return result.output;
}
function createSanitizer(options = {}) {
  const keyEncoding = options.keyEncoding ?? "hex";
  const key = options.key ?? generateKey();
  assertKey(key, keyEncoding);
  const contextChars = options.report?.contextChars ?? 0;
  if (contextChars < 0) {
    throw new chunkVELXTD3L_cjs.InvalidOptionError("report.contextChars must not be negative.");
  }
  const selected = resolveWithAlwaysRedact(options);
  const ctx = createRuleContext({
    rules: selected,
    aggressive: options.aggressive ?? false,
    pseudonymize: createPseudonymizer(key, keyEncoding),
    allow: createAllowList(options.neverRedact),
    contextChars,
    json: options.json !== false
  });
  const collectorOptions = {
    previewBytes: options.report?.previewBytes,
    replacements: options.report?.replacements,
    maxReplacementsPerRule: options.report?.maxReplacementsPerRule
  };
  const rules = selected.map((rule) => ({
    id: rule.id,
    label: rule.label,
    description: rule.description,
    mode: rule.mode
  }));
  function sanitizeText2(text) {
    const collector = createReportCollector(collectorOptions);
    const splitter = createLineSplitter(options.lines);
    let output = "";
    for (const line of splitter.push(text)) {
      output += processLine(line, ctx, collector);
    }
    for (const line of splitter.flush()) {
      output += processLine(line, ctx, collector);
    }
    return { output, report: collector.build() };
  }
  async function sanitizeStream2(source, sink, streamOptions = {}) {
    const collector = createReportCollector({
      ...collectorOptions,
      ...streamOptions.previewBytes !== void 0 ? { previewBytes: streamOptions.previewBytes } : {}
    });
    const splitter = createLineSplitter(options.lines);
    const { signal, onProgress } = streamOptions;
    let charsRead = 0;
    const writeLine = async (line) => {
      if (signal?.aborted === true) {
        throw new chunkVELXTD3L_cjs.SanitizationAbortedError();
      }
      await sink.write(processLine(line, ctx, collector));
    };
    for await (const chunk of toAsyncIterable(source)) {
      charsRead += chunk.length;
      for (const line of splitter.push(chunk)) {
        await writeLine(line);
      }
      onProgress?.({ charsRead, report: collector.build({ includeReplacements: false }) });
    }
    for (const line of splitter.flush()) {
      await writeLine(line);
    }
    await sink.close?.();
    return collector.build();
  }
  return { key, rules, sanitizeText: sanitizeText2, sanitizeStream: sanitizeStream2 };
}
function resolveWithAlwaysRedact(options) {
  const selected = resolveRules(options.rules ?? chunkVELXTD3L_cjs.builtinRuleIds, options.extraRules);
  const alwaysRule = createAlwaysRedactRule(options.alwaysRedact);
  if (!alwaysRule) {
    return selected;
  }
  if (selected.some((rule) => rule.id === alwaysRule.id)) {
    throw new chunkVELXTD3L_cjs.InvalidOptionError(
      `alwaysRedact.ruleId "${alwaysRule.id}" collides with an active rule. Choose an identifier that is not in use.`
    );
  }
  return [alwaysRule, ...selected];
}
function sanitizeText(text, options) {
  return createSanitizer(options).sanitizeText(text);
}
function sanitizeStream(source, sink, options) {
  const { onProgress, signal, previewBytes, ...sanitizerOptions } = options ?? {};
  return createSanitizer(sanitizerOptions).sanitizeStream(source, sink, {
    onProgress,
    signal,
    previewBytes
  });
}

// src/core/mergeReports.ts
function emptyReport() {
  return {
    counts: {},
    totalMatches: 0,
    lineCount: 0,
    replacements: [],
    preview: { before: [], after: [] }
  };
}
function cloneReplacement(row) {
  return {
    ruleId: row.ruleId,
    original: row.original,
    replacement: row.replacement,
    count: row.count,
    ...row.contextBefore !== void 0 ? { contextBefore: row.contextBefore, contextAfter: row.contextAfter } : {}
  };
}
function mergePreview(reports, previewBytes) {
  if (previewBytes === 0) {
    return { before: [], after: [] };
  }
  const before = [];
  const after = [];
  let used = 0;
  for (const report of reports) {
    const afterSegs = report.preview.after;
    const beforeSegs = report.preview.before;
    for (let i = 0; i < afterSegs.length; i += 1) {
      if (used >= previewBytes) {
        return { before, after };
      }
      after.push(afterSegs[i]);
      before.push(beforeSegs[i] ?? { text: "", changed: false });
      used += afterSegs[i].text.length;
    }
  }
  return { before, after };
}
function mergeReports(reports, options = {}) {
  if (reports.length === 0) {
    return emptyReport();
  }
  const previewBytes = options.previewBytes ?? DEFAULT_PREVIEW_BYTES;
  const maxPerRule = options.maxReplacementsPerRule;
  const limited = maxPerRule !== void 0;
  const counts = {};
  const replacements = /* @__PURE__ */ new Map();
  const perRuleDistinct = limited ? /* @__PURE__ */ new Map() : null;
  let lineCount = 0;
  let truncated = false;
  for (const report of reports) {
    lineCount += report.lineCount;
    if (report.replacementsTruncated === true) {
      truncated = true;
    }
    for (const [id, count] of Object.entries(report.counts)) {
      counts[id] = (counts[id] ?? 0) + (count ?? 0);
    }
    for (const row of report.replacements) {
      const key = `${row.ruleId}\0${row.original}`;
      const existing = replacements.get(key);
      if (existing) {
        existing.count += row.count;
        continue;
      }
      if (maxPerRule !== void 0 && perRuleDistinct) {
        const n = perRuleDistinct.get(row.ruleId) ?? 0;
        if (n >= maxPerRule) {
          truncated = true;
          continue;
        }
        perRuleDistinct.set(row.ruleId, n + 1);
      }
      replacements.set(key, cloneReplacement(row));
    }
  }
  let totalMatches = 0;
  for (const count of Object.values(counts)) {
    totalMatches += count;
  }
  return {
    counts,
    totalMatches,
    lineCount,
    replacements: [...replacements.values()],
    preview: mergePreview(reports, previewBytes),
    ...truncated ? { replacementsTruncated: true } : {}
  };
}

// src/io/sources.ts
var DEFAULT_CHUNK_BYTES = 4 * 1024 * 1024;
function fromString(text, chunkChars = DEFAULT_CHUNK_BYTES) {
  return {
    *[Symbol.iterator]() {
      for (let offset = 0; offset < text.length; offset += chunkChars) {
        yield text.slice(offset, offset + chunkChars);
      }
    }
  };
}
function fromBlob(blob, chunkBytes = DEFAULT_CHUNK_BYTES) {
  return {
    async *[Symbol.asyncIterator]() {
      const decoder = new TextDecoder("utf-8");
      for (let offset = 0; offset < blob.size; offset += chunkBytes) {
        const slice = blob.slice(offset, Math.min(offset + chunkBytes, blob.size));
        const buffer = await slice.arrayBuffer();
        const text = decoder.decode(new Uint8Array(buffer), { stream: true });
        if (text.length > 0) {
          yield text;
        }
      }
      const tail = decoder.decode();
      if (tail.length > 0) {
        yield tail;
      }
    }
  };
}
function fromWebStream(stream) {
  return {
    async *[Symbol.asyncIterator]() {
      const reader = stream.getReader();
      const decoder = new TextDecoder("utf-8");
      try {
        for (; ; ) {
          const { done, value } = await reader.read();
          if (done) {
            break;
          }
          if (value === void 0) {
            continue;
          }
          const text = typeof value === "string" ? value : decoder.decode(value, { stream: true });
          if (text.length > 0) {
            yield text;
          }
        }
        const tail = decoder.decode();
        if (tail.length > 0) {
          yield tail;
        }
      } finally {
        reader.releaseLock();
      }
    }
  };
}

// src/io/planLineRanges.ts
var LF = 10;
async function snapToNewline(blob, from, probeBytes, maxProbeBytes) {
  if (from <= 0 || from >= blob.size) {
    return null;
  }
  let scanned = 0;
  let window = probeBytes;
  while (scanned < maxProbeBytes && from + scanned < blob.size) {
    const chunkEnd = Math.min(from + Math.min(window, maxProbeBytes), blob.size);
    const buffer = await blob.slice(from + scanned, chunkEnd).arrayBuffer();
    const bytes = new Uint8Array(buffer);
    const idx = bytes.indexOf(LF);
    if (idx !== -1) {
      return from + scanned + idx + 1;
    }
    scanned = chunkEnd - from;
    window = Math.min(window * 2, maxProbeBytes);
  }
  return null;
}
async function planLineAlignedRanges(blob, partCount, options = {}) {
  if (!Number.isInteger(partCount) || partCount < 1) {
    throw new chunkVELXTD3L_cjs.InvalidOptionError("partCount must be an integer >= 1.");
  }
  const probeBytes = options.probeBytes ?? DEFAULT_RANGE_PROBE_BYTES;
  const maxProbeBytes = options.maxProbeBytes ?? DEFAULT_RANGE_MAX_PROBE_BYTES;
  if (!Number.isInteger(probeBytes) || probeBytes < 1) {
    throw new chunkVELXTD3L_cjs.InvalidOptionError("probeBytes must be an integer >= 1.");
  }
  if (!Number.isInteger(maxProbeBytes) || maxProbeBytes < probeBytes) {
    throw new chunkVELXTD3L_cjs.InvalidOptionError("maxProbeBytes must be an integer >= probeBytes.");
  }
  if (blob.size <= 0) {
    return [];
  }
  if (partCount === 1) {
    return [{ start: 0, end: blob.size }];
  }
  const cuts = /* @__PURE__ */ new Set();
  for (let i = 1; i < partCount; i += 1) {
    const nominal = Math.round(blob.size * i / partCount);
    const snapped = await snapToNewline(blob, nominal, probeBytes, maxProbeBytes);
    if (snapped !== null && snapped > 0 && snapped < blob.size) {
      cuts.add(snapped);
    }
  }
  const bounds = [0, ...[...cuts].sort((a, b) => a - b), blob.size];
  const ranges = [];
  for (let i = 0; i < bounds.length - 1; i += 1) {
    const start = bounds[i];
    const end = bounds[i + 1];
    if (end > start) {
      ranges.push({ start, end });
    }
  }
  return ranges;
}

// src/io/sinks.ts
function toStringSink() {
  const chunks = [];
  return {
    write(chunk) {
      chunks.push(chunk);
    },
    get text() {
      return chunks.join("");
    }
  };
}
function toCallbackSink(onChunk, onClose) {
  return {
    write: onChunk,
    ...onClose ? { close: onClose } : {}
  };
}
function toNullSink() {
  return { write: () => void 0 };
}

exports.createSanitizer = createSanitizer;
exports.fromBlob = fromBlob;
exports.fromString = fromString;
exports.fromWebStream = fromWebStream;
exports.generateKey = generateKey;
exports.mergeReports = mergeReports;
exports.planLineAlignedRanges = planLineAlignedRanges;
exports.sanitizeStream = sanitizeStream;
exports.sanitizeText = sanitizeText;
exports.toCallbackSink = toCallbackSink;
exports.toNullSink = toNullSink;
exports.toStringSink = toStringSink;
//# sourceMappingURL=chunk-ZCWN2P2R.cjs.map
//# sourceMappingURL=chunk-ZCWN2P2R.cjs.map