export { builtinRuleIds, builtinRules, defineRule, getBuiltinRule } from './chunk-X2QYRBY6.js';
//# sourceMappingURL=rules.js.map
//# sourceMappingURL=rules.js.map