'use strict';

var chunkVELXTD3L_cjs = require('./chunk-VELXTD3L.cjs');



Object.defineProperty(exports, "builtinRuleIds", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.builtinRuleIds; }
});
Object.defineProperty(exports, "builtinRules", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.builtinRules; }
});
Object.defineProperty(exports, "defineRule", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.defineRule; }
});
Object.defineProperty(exports, "getBuiltinRule", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.getBuiltinRule; }
});
//# sourceMappingURL=rules.cjs.map
//# sourceMappingURL=rules.cjs.map