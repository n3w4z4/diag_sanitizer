'use strict';

var chunkZCWN2P2R_cjs = require('./chunk-ZCWN2P2R.cjs');
var chunkVELXTD3L_cjs = require('./chunk-VELXTD3L.cjs');



Object.defineProperty(exports, "createSanitizer", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.createSanitizer; }
});
Object.defineProperty(exports, "fromBlob", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.fromBlob; }
});
Object.defineProperty(exports, "fromString", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.fromString; }
});
Object.defineProperty(exports, "fromWebStream", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.fromWebStream; }
});
Object.defineProperty(exports, "generateKey", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.generateKey; }
});
Object.defineProperty(exports, "mergeReports", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.mergeReports; }
});
Object.defineProperty(exports, "planLineAlignedRanges", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.planLineAlignedRanges; }
});
Object.defineProperty(exports, "sanitizeStream", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.sanitizeStream; }
});
Object.defineProperty(exports, "sanitizeText", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.sanitizeText; }
});
Object.defineProperty(exports, "toCallbackSink", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.toCallbackSink; }
});
Object.defineProperty(exports, "toNullSink", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.toNullSink; }
});
Object.defineProperty(exports, "toStringSink", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.toStringSink; }
});
Object.defineProperty(exports, "InvalidKeyError", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.InvalidKeyError; }
});
Object.defineProperty(exports, "InvalidOptionError", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.InvalidOptionError; }
});
Object.defineProperty(exports, "InvalidRuleError", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.InvalidRuleError; }
});
Object.defineProperty(exports, "SanitizationAbortedError", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.SanitizationAbortedError; }
});
Object.defineProperty(exports, "SanitizerError", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.SanitizerError; }
});
Object.defineProperty(exports, "UnknownRuleError", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.UnknownRuleError; }
});
Object.defineProperty(exports, "builtinRuleIds", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.builtinRuleIds; }
});
Object.defineProperty(exports, "builtinRules", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.builtinRules; }
});
Object.defineProperty(exports, "defineRule", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.defineRule; }
});
Object.defineProperty(exports, "getBuiltinRule", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.getBuiltinRule; }
});
Object.defineProperty(exports, "isSanitizerError", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.isSanitizerError; }
});
//# sourceMappingURL=index.cjs.map
//# sourceMappingURL=index.cjs.map