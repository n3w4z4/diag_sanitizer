'use strict';

var chunkZCWN2P2R_cjs = require('./chunk-ZCWN2P2R.cjs');
var chunkVELXTD3L_cjs = require('./chunk-VELXTD3L.cjs');
var fs = require('fs');
var events = require('events');
var promises = require('stream/promises');

var DEFAULT_CHUNK_BYTES = 4 * 1024 * 1024;
function fromNodeStream(stream) {
  return {
    async *[Symbol.asyncIterator]() {
      const decoder = new TextDecoder("utf-8");
      for await (const chunk of stream) {
        const text = typeof chunk === "string" ? chunk : decoder.decode(chunk, { stream: true });
        if (text.length > 0) {
          yield text;
        }
      }
      const tail = decoder.decode();
      if (tail.length > 0) {
        yield tail;
      }
    }
  };
}
function fromFile(path, chunkBytes = DEFAULT_CHUNK_BYTES) {
  return fromNodeStream(fs.createReadStream(path, { highWaterMark: chunkBytes }));
}
function toNodeStream(stream) {
  return {
    async write(chunk) {
      if (!stream.write(chunk)) {
        await events.once(stream, "drain");
      }
    }
  };
}
function toFile(path) {
  const stream = fs.createWriteStream(path, { encoding: "utf-8" });
  const target = toNodeStream(stream);
  return {
    write: target.write.bind(target),
    async close() {
      stream.end();
      await promises.finished(stream);
    }
  };
}
async function sanitizeFile(options) {
  const { input, output, chunkBytes, onProgress, signal, ...sanitizerOptions } = options;
  const sanitizer = chunkZCWN2P2R_cjs.createSanitizer(sanitizerOptions);
  const sink = output === void 0 ? chunkZCWN2P2R_cjs.toNullSink() : toFile(output);
  return sanitizer.sanitizeStream(fromFile(input, chunkBytes), sink, { onProgress, signal });
}

Object.defineProperty(exports, "createSanitizer", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.createSanitizer; }
});
Object.defineProperty(exports, "fromBlob", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.fromBlob; }
});
Object.defineProperty(exports, "fromString", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.fromString; }
});
Object.defineProperty(exports, "fromWebStream", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.fromWebStream; }
});
Object.defineProperty(exports, "generateKey", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.generateKey; }
});
Object.defineProperty(exports, "mergeReports", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.mergeReports; }
});
Object.defineProperty(exports, "planLineAlignedRanges", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.planLineAlignedRanges; }
});
Object.defineProperty(exports, "sanitizeStream", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.sanitizeStream; }
});
Object.defineProperty(exports, "sanitizeText", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.sanitizeText; }
});
Object.defineProperty(exports, "toCallbackSink", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.toCallbackSink; }
});
Object.defineProperty(exports, "toNullSink", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.toNullSink; }
});
Object.defineProperty(exports, "toStringSink", {
  enumerable: true,
  get: function () { return chunkZCWN2P2R_cjs.toStringSink; }
});
Object.defineProperty(exports, "InvalidKeyError", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.InvalidKeyError; }
});
Object.defineProperty(exports, "InvalidOptionError", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.InvalidOptionError; }
});
Object.defineProperty(exports, "InvalidRuleError", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.InvalidRuleError; }
});
Object.defineProperty(exports, "SanitizationAbortedError", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.SanitizationAbortedError; }
});
Object.defineProperty(exports, "SanitizerError", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.SanitizerError; }
});
Object.defineProperty(exports, "UnknownRuleError", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.UnknownRuleError; }
});
Object.defineProperty(exports, "builtinRuleIds", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.builtinRuleIds; }
});
Object.defineProperty(exports, "builtinRules", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.builtinRules; }
});
Object.defineProperty(exports, "defineRule", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.defineRule; }
});
Object.defineProperty(exports, "getBuiltinRule", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.getBuiltinRule; }
});
Object.defineProperty(exports, "isSanitizerError", {
  enumerable: true,
  get: function () { return chunkVELXTD3L_cjs.isSanitizerError; }
});
exports.fromFile = fromFile;
exports.fromNodeStream = fromNodeStream;
exports.sanitizeFile = sanitizeFile;
exports.toFile = toFile;
exports.toNodeStream = toNodeStream;
//# sourceMappingURL=node.cjs.map
//# sourceMappingURL=node.cjs.map