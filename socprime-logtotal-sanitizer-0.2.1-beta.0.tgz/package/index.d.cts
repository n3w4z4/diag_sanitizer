import { S as SanitizerOptions, r as Sanitizer, T as TextSource, c as TextSink, p as SanitizeStreamOptions, b as SanitizeReport, q as SanitizeTextResult, B as BlobLike, R as ReadableStreamLike } from './index-BYEGdnwh.cjs';
export { A as AbortSignalLike, d as AlwaysRedactOptions, e as BuiltinRuleId, K as KeyEncoding, L as LineOptions, N as NeverRedactOptions, f as NeverRedactRuleEntry, g as RedactionMode, h as ReportOptions, i as RuleCounts, j as RuleId, k as RuleInfo, l as RuleSelector, a as SanitizeProgress, m as SanitizeReplacement, n as SanitizeRule, o as SanitizeSegment, s as builtinRuleIds, t as builtinRules, u as defineRule, v as getBuiltinRule } from './index-BYEGdnwh.cjs';

/**
 * Machine-readable cause of a {@link SanitizerError}.
 */
type SanitizerErrorCode = 'INVALID_RULE' | 'UNKNOWN_RULE' | 'INVALID_KEY' | 'INVALID_OPTION' | 'ABORTED';
/**
 * Base class for every error this package throws.
 */
declare class SanitizerError extends Error {
    /** Machine-readable cause, stable across releases. */
    readonly code: SanitizerErrorCode;
    constructor(code: SanitizerErrorCode, message: string);
}
/** A rule object is malformed. */
declare class InvalidRuleError extends SanitizerError {
    constructor(message: string);
}
/** A rule identifier does not match any built-in rule. */
declare class UnknownRuleError extends SanitizerError {
    constructor(message: string);
}
/** A key is malformed, or no secure random source is available to generate one. */
declare class InvalidKeyError extends SanitizerError {
    constructor(message: string);
}
/** An option value is outside its allowed range. */
declare class InvalidOptionError extends SanitizerError {
    constructor(message: string);
}
/** A streaming run was stopped through its `AbortSignal`. */
declare class SanitizationAbortedError extends SanitizerError {
    constructor(message?: string);
}
/**
 * Whether a caught value is an error thrown by this package.
 *
 * Prefer this over `instanceof` when the value may have crossed a bundle, worker or realm
 * boundary, where class identity is not preserved.
 */
declare function isSanitizerError(value: unknown): value is SanitizerError;

/**
 * Generates a random hex-encoded key for token derivation.
 *
 * Persist the returned value if tokens have to stay comparable across runs or files; discard it if
 * they should not. There is no way to recover the original values from the tokens, with or without
 * the key — the key only determines which token a given value maps to.
 *
 * @param byteLength Key length in bytes, at least 16.
 * @throws {InvalidKeyError} When `byteLength` is too small or no secure random source is available.
 *
 * @example
 * ```ts
 * const key = generateKey();
 * const sanitizer = createSanitizer({ key });
 * ```
 */
declare function generateKey(byteLength?: number): string;

declare function createSanitizer(options?: SanitizerOptions): Sanitizer;
/**
 * Sanitizes a string with a one-off configuration.
 *
 * Convenient for scripts and tests. Each call builds a new sanitizer, so unless `options.key` is
 * supplied the tokens are not comparable between calls. For repeated use, create a sanitizer with
 * {@link createSanitizer} instead.
 */
declare function sanitizeText(text: string, options?: SanitizerOptions): SanitizeTextResult;
declare function sanitizeStream(source: TextSource, sink: TextSink, options?: SanitizerOptions & SanitizeStreamOptions): Promise<SanitizeReport>;

interface MergeReportsOptions {
    previewBytes?: number;
    maxReplacementsPerRule?: number;
}
declare function mergeReports(reports: readonly SanitizeReport[], options?: MergeReportsOptions): SanitizeReport;

/**
 * Wraps a string as a source, split into fixed-size chunks.
 *
 * Useful for exercising the streaming path in tests and for feeding text that is already in memory
 * without copying it in one piece.
 */
declare function fromString(text: string, chunkChars?: number): TextSource;
/**
 * Reads a `Blob` or `File` as UTF-8 text, one chunk at a time.
 *
 * Multi-byte characters split across a chunk boundary are decoded correctly. Accepts any object
 * with `size`, `slice` and `arrayBuffer`, so browser `File`, browser `Blob` and Node's `Blob` all
 * work.
 *
 * @example
 * ```ts
 * const report = await sanitizer.sanitizeStream(fromBlob(file), toStringSink());
 * ```
 */
declare function fromBlob(blob: BlobLike, chunkBytes?: number): TextSource;
/**
 * Reads a `ReadableStream` of text or bytes.
 *
 * Byte chunks are decoded as UTF-8 across chunk boundaries. Accepts web streams from `fetch`,
 * `Blob.stream()` and `node:stream/web`.
 */
declare function fromWebStream(stream: ReadableStreamLike<string | Uint8Array>): TextSource;

interface ByteRange {
    start: number;
    end: number;
}
interface PlanLineRangesOptions {
    probeBytes?: number;
    maxProbeBytes?: number;
}
declare function planLineAlignedRanges(blob: BlobLike, partCount: number, options?: PlanLineRangesOptions): Promise<ByteRange[]>;

/** A sink that accumulates everything in memory. */
interface StringSink extends TextSink {
    /** Everything written so far, joined. */
    readonly text: string;
}
/**
 * Collects sanitized output into a string.
 *
 * Only appropriate when the output is known to fit in memory — the point of the streaming API is
 * usually to avoid that.
 *
 * @example
 * ```ts
 * const sink = toStringSink();
 * const report = await sanitizer.sanitizeStream(fromString(input), sink);
 * console.log(sink.text, report.totalMatches);
 * ```
 */
declare function toStringSink(): StringSink;
/**
 * Sends sanitized output to a callback, one line at a time.
 *
 * The callback may return a promise; it is awaited before the next line is written, so
 * backpressure propagates to the source.
 */
declare function toCallbackSink(onChunk: (chunk: string) => void | Promise<void>, onClose?: () => void | Promise<void>): TextSink;
/** A sink that discards everything, for report-only runs. */
declare function toNullSink(): TextSink;

export { BlobLike, type ByteRange, InvalidKeyError, InvalidOptionError, InvalidRuleError, type MergeReportsOptions, type PlanLineRangesOptions, ReadableStreamLike, SanitizationAbortedError, SanitizeReport, SanitizeStreamOptions, SanitizeTextResult, Sanitizer, SanitizerError, type SanitizerErrorCode, SanitizerOptions, type StringSink, TextSink, TextSource, UnknownRuleError, createSanitizer, fromBlob, fromString, fromWebStream, generateKey, isSanitizerError, mergeReports, planLineAlignedRanges, sanitizeStream, sanitizeText, toCallbackSink, toNullSink, toStringSink };
